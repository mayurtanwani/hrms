import React from "react";

const Middletext = () => {
  return (
    <div>
      <div className="headlinediv">
        <h1>
          <span className="cyan">Teamwork</span> Makes The Dreamwork.
        </h1>
      </div>
      <p className="text">
        {" "}
        It Involves Various Activities Such As Job Analysis, Job Posting,
        Candidate Search, Candidate Screening, Interviewing, And Onboadring
        Effective Recruitment Management Is Essential For Organizations To Find
        The Right Candidates.{" "}
      </p>
    </div>
  );
};

export default Middletext;
