import { useEffect, useState } from "react";
import React from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import Moment from "react-moment";
import moment from "moment";
import Leftsidebar from "./Leftsidebar";
import Loggedintopbar from "./Loggedintopbar";
import Table from "react-bootstrap/Table";
import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getAttendance } from "../redux/actions/actions";
import { Link } from "react-router-dom";

const InOutSheetDetails = () => {
  const [date, setDate] = useState(new Date());
  const today = new Date();
  const options = { day: "numeric", month: "long", year: "numeric" };
  const formattedDate = today.toLocaleDateString("en-US", options);
  const location = useLocation();
  const { eid } = location.state;
  const { attendanceData } = useSelector((state) => state.attendanceData);
  const dispatch = useDispatch();

  console.log(attendanceData);

  useEffect(() => {
    dispatch(getAttendance());
  }, []);

  return (
    <>
      <div className="inoutsheetdetailsmain d-flex">
        <div className="inoutsheetdetailsleft">
          <Leftsidebar />
        </div>
        <div className="inoutsheetdetailsright">
          <Loggedintopbar text="In-Out Sheet" />
          <div className="d-flex justify-content-between align-items-center mt-5 ps-5 pe-1">
            <div
              style={{
                fontFamily: "Poppins",
                fontWeight: "600",
                fontSize: "18px",
                lineHeight: "27px",
              }}
              className="d-flex align-items-center"
            >
              <div>
                <Link to="/inoutsheet">
                  <span
                    style={{
                      textDecoration: "none",
                      fontSize: "25px",
                      color: "black     ",
                    }}
                  >
                    &lt;
                  </span>
                </Link>
              </div>
              <div className="ms-2">{formattedDate}</div>
            </div>
            <div style={{ width: "200px" }}>
              <DatePicker
                selected={date}
                onChange={(date) => setDate(date)}
                dateFormat="MMMM yyyy"
                showMonthYearPicker
                monthsShown={1}
                showIcon
              />
            </div>
          </div>

          <Table className="mt-5" style={{ margin: "0 auto" }}>
            <thead>
              <tr>
                <th>Eid</th>
                <th>Date</th>
                <th>Start Time</th>
                <th>End Time</th>
                <th>Status</th>
                <th>Total Hours</th>
              </tr>
            </thead>

            <tbody>
              {attendanceData &&
                attendanceData.allAttendance
                  .filter((item) => {
                    const itemDate = moment(item.date);
                    const selectedMonth = moment(date).month();
                    return (
                      item.eid === eid && itemDate.month() === selectedMonth
                    );
                  })
                  .map((item, i) => {
                    const startTime = moment(item.starttime, "HH:mm");
                    const endTime = moment(item.endtime, "HH:mm");
                    const diff = moment.duration(endTime.diff(startTime));
                    const hours = diff.hours();
                    const minutes = diff.minutes();
                    return (
                      <tr>
                        <td>
                          {Number(item.eid) < 10 ? `0${item.eid}` : item.eid}
                        </td>
                        <td>
                          <Moment format="DD-MM-YYYY">{item.date}</Moment>
                        </td>
                        <td>
                          {item.status == "Absent"
                            ? "N/A"
                            : startTime.format("hh:mm A")}
                        </td>
                        <td>
                          {item.status == "Absent"
                            ? "N/A"
                            : endTime.format("hh:mm A")}
                        </td>
                        <td>
                          <span
                            className={
                              item.status == "Present"
                                ? "presentclass"
                                : item.status == "Absent"
                                ? "absentclass"
                                : item.status == "halfday"
                                ? "halfday"
                                : ""
                            }
                          >
                            {item.status}
                          </span>
                        </td>
                        <td>
                          {item.status == "Absent"
                            ? "N/A"
                            : `${hours}:${minutes}`}
                        </td>
                      </tr>
                    );
                  })}
            </tbody>
          </Table>
        </div>
      </div>
    </>
  );
};

export default InOutSheetDetails;
