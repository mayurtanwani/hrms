import React from "react";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";

const Hiring = () => {
  return (
    <div className="hiringcontent">
      <div className="hiretext">
        <h4>You Need To Hire</h4>
      </div>

      <div className="hiringdata">
        <div className="singledata">
          <h1 className="vacancies">3</h1>
          <div className="group">
            <p className="jobtitle">PHP Developers</p>
            <p className="candidates">(5 candidates)</p>
          </div>
          <div className="circularbar" style={{ width: 100, height: 100 }}>
            <CircularProgressbar strokeWidth={6} value={75} text={"75%"} />
          </div>
        </div>
        <div className="singledata">
          <h1 className="vacancies">9</h1>
          <div className="group">
            <p className="jobtitle">Node JS Developers</p>
            <p className="candidates">(12 candidates)</p>
          </div>
          <div className="circularbar" style={{ width: 100, height: 100 }}>
            <CircularProgressbar
              strokeWidth={6}
              styles={buildStyles({
                pathColor: "orange",
                textColor: "orange",
              })}
              value={30}
              text={"30%"}
            />
          </div>
        </div>
        <div className="singledata">
          <h1 className="vacancies">0</h1>
          <div className="group">
            <p className="jobtitle">UI designers</p>
            <p className="candidates">(0 candidates)</p>
          </div>
          <div className="circularbar" style={{ width: 100, height: 100 }}>
            <CircularProgressbar
              strokeWidth={6}
              styles={buildStyles({
                pathColor: "grey",
                textColor: "grey",
              })}
              value={0}
              text={"0%"}
            />
          </div>
        </div>
        <div className="singledata">
          <h1 className="vacancies">2</h1>
          <div className="group">
            <p className="jobtitle">BDE</p>
            <p className="candidates">(4 candidates)</p>
          </div>
          <div className="circularbar" style={{ width: 100, height: 100 }}>
            <CircularProgressbar
              strokeWidth={6}
              styles={buildStyles({
                pathColor: "green",
                textColor: "green",
              })}
              value={80}
              text={"80%"}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hiring;
