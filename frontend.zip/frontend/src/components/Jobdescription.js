import React from "react";
import Leftsidebar from "./Leftsidebar";
import Loggedintopbar from "./Loggedintopbar";
import uiux from "../assets/uiux.png";
import reactnative from "../assets/react.png";
import nodedeveloper from "../assets/Node Developer.png";
import wordpress from "../assets/Wordpress.png";
import phpdeveloper from "../assets/PHP Developer.png";
import Drupal from "../assets/Drupal.png";
const Jobdescription = () => {
  return (
    <div className="JDmain">
      <div className="leftsidebarpettycash">
        <Leftsidebar />
      </div>
      <div className="pettycashright">
        <div>
          <Loggedintopbar text="Job Description" />
        </div>

        <div className="jobdescriptions">
          <div className="job">
            <img src={uiux} />
            <h6>UI/UX Designer</h6>
            <p>
              UI/UX Designer Investigation user experience design requirement
              for our suite of digital assets. Knowledge of colors, typography,
              and design
              <span className="vm"> View more</span>
            </p>
          </div>

          <div className="job">
            <img src={reactnative} />
            <h6>React Native Developer</h6>
            <p>
              React Native Developer Investigation user experience design
              requirement for our suite of digital assets. Knowledge of colors,
              typography, and design.
              <span className="vm">View more</span>
            </p>
          </div>

          <div className="job">
            <img src={nodedeveloper} />
            <h6>Node Developer</h6>
            <p>
              Investigation user experience design requirement for our suite of
              digital assets. Knowledge of colors, typography, and design.
              <span className="vm"> View more</span>
            </p>
          </div>

          <div className="job">
            <img src={wordpress} />
            <h6>Wordpress Developer</h6>
            <p>
              Investigation user experience design requirement for our suite of
              digital assets. Knowledge of colors, typography, and design.
              <span className="vm">View more</span>
            </p>
          </div>

          <div className="job">
            <img src={phpdeveloper} />
            <h6>PHP Developer</h6>
            <p>
              Investigation user experience design requirement for our suite of
              digital assets. Knowledge of colors, typography, and design.
              <span className="vm">View more</span>
            </p>
          </div>

          <div className="job">
            <img src={Drupal} />
            <h6>Drupal Developer</h6>
            <p>
              Investigation user experience design requirement for our suite of
              digital assets. Knowledge of colors, typography, and design.
              <span className="vm">View more</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Jobdescription;
