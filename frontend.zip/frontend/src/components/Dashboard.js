import React from "react";
import Dashboardtopbar from "./Dashboardtopbar";
import Hiring from "./Hiring";
import Leftsidebar from "./Leftsidebar";
import Loggedintopbar from "./Loggedintopbar";
import Recruitment from "./Recruitment";
import Welcomediv from "./Welcomediv";

const Dashboard = () => {
  return (
    <div className="dashboard">
      <div className="dashboardleft">
        <Leftsidebar />
      </div>
      <div className="dashboardright">
        <Loggedintopbar text="Dashboard" />
        <Welcomediv />
        <Hiring />
        <Recruitment />
      </div>
    </div>
  );
};

export default Dashboard;
