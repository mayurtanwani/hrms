import React from "react";
import { Sidebar, Menu, MenuItem, SubMenu } from "react-pro-sidebar";
import employee from "../assets/Employee.png";
import attendence from "../assets/Attendence.png";
import payroll from "../assets/Payroll.png";
import recruitment from "../assets/recruiter.png";
import dashboard from "../assets/dashboard.png";
import logo from "../assets/ntf.png";
import birthday from "../assets/Birthday.png";
import logout from "../assets/logout.png";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { useEffect } from "react";
import { fetchProducts } from "../redux/actions/actions";
import moment from "moment";
import Moment from "react-moment";

const Leftsidebar = () => {
  const navigate = useNavigate();

  const { data } = useSelector((state) => state.data);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchProducts());
  }, []);

  const handleLogout = (e) => {
    e.preventDefault();
    localStorage.removeItem("token");
    navigate("/");
  };

  const sortedEmployees =
    data &&
    data.sort((a, b) => {
      const today = new Date();

      const aDob = new Date(a.dob);
      const bDob = new Date(b.dob);

      const aDobThisYear = new Date(
        today.getFullYear(),
        aDob.getMonth(),
        aDob.getDate()
      );

      const bDobThisYear = new Date(
        today.getFullYear(),
        bDob.getMonth(),
        bDob.getDate()
      );

      const aTimeDiff = aDobThisYear.getTime() - today.getTime();
      const bTimeDiff = bDobThisYear.getTime() - today.getTime();

      if (aTimeDiff < 0) {
        aDobThisYear.setFullYear(today.getFullYear() + 1);
      }

      if (bTimeDiff < 0) {
        bDobThisYear.setFullYear(today.getFullYear() + 1);
      }

      return aDobThisYear.getTime() - bDobThisYear.getTime();
    });

  const nearestBirthdayArray = [];
  sortedEmployees && nearestBirthdayArray.push(sortedEmployees[0]);
  const birthDatefirst =
    sortedEmployees && new Date(nearestBirthdayArray[0].dob);
  const monthfirst = sortedEmployees && birthDatefirst.getMonth();
  const datefirst = sortedEmployees && birthDatefirst.getDate();

  if (sortedEmployees && sortedEmployees.length > 0) {
    for (let i = 1; i < sortedEmployees.length; i++) {
      const check = new Date(sortedEmployees[i].dob);
      const checkmonth = check.getMonth();
      const checkdate = check.getDate();

      if (checkmonth == monthfirst && checkdate == datefirst) {
        nearestBirthdayArray.push(sortedEmployees[i]);
      }
    }
  }

  const date = sortedEmployees && new Date(nearestBirthdayArray[0].dob);

  let namestring = "";
  if (sortedEmployees && sortedEmployees.length > 0) {
    for (let i = 0; i < nearestBirthdayArray.length; i++) {
      namestring =
        namestring +
        " , " +
        nearestBirthdayArray[i].firstname +
        " " +
        nearestBirthdayArray[i].lastname;
    }
  }

  const finalarray = [date, namestring.slice(3)];

  return (
    <Sidebar className="sidebar">
      <Menu>
        <Link className="sidebarlogo" to="/">
          <img src={logo} />
        </Link>
        <div className="menulinks">
          <MenuItem
            component={<Link to="/dashboard" />}
            icon={<img src={dashboard} />}
          >
            Dashboard
          </MenuItem>
          <SubMenu icon={<img src={employee} />} label="Employees">
            <MenuItem component={<Link to="/newemployee" />}>
              Current Employees
            </MenuItem>

            <MenuItem component={<Link to="/oldemployee" />}>
              Old Employees
            </MenuItem>
          </SubMenu>
          <SubMenu icon={<img src={recruitment} />} label="Recruitment">
            <MenuItem component={<Link to="/resumerepository" />}>
              Resume Repository
            </MenuItem>
            <MenuItem component={<Link to="/jobdescription" />}>
              Job Description
            </MenuItem>
          </SubMenu>
          <SubMenu icon={<img src={payroll} />} label="Payroll">
            <MenuItem component={<Link to="/salary" />}> Salary </MenuItem>
            <MenuItem component={<Link to="/pettycash" />}>Petty Cash</MenuItem>
          </SubMenu>
          <SubMenu icon={<img src={attendence} />} label="Attendence">
            <MenuItem component={<Link to="/inoutsheet" />}>
              {" "}
              In-out Sheet{" "}
            </MenuItem>
            <MenuItem component={<Link to="/attendancesheet" />}>
              {" "}
              Attendence Sheet{" "}
            </MenuItem>
            <MenuItem component={<Link to="/leaves" />}> Leaves </MenuItem>
          </SubMenu>
        </div>
        <div className="birthdaypic">
          <img src={birthday} />
        </div>

        <div className="textdiv">
          <span>
            <Moment format="D MMMM YYYY">{finalarray[0]}</Moment>
          </span>
          <br />
          <span>{finalarray[1]}</span>
          <br />
          <span>Birthday</span>
        </div>

        <div className="logoutdiv">
          <button onClick={handleLogout} className="logoutbutton">
            <img src={logout} /> Logout
          </button>
        </div>
      </Menu>
    </Sidebar>
  );
};

export default Leftsidebar;
