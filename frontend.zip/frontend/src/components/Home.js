import React, { useEffect } from "react";
import HomeImage from "./HomeImage";
import Middletext from "./Middletext";
import SalarySheet from "./SalarySheet";
import Screening from "./Screening";
import Topbar from "./Topbar";
import picture1 from "../assets/Group 14.png";
import picture2 from "../assets/Group 12.png";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

const Home = () => {
  const navigate = useNavigate();
  const loginbuttontext = "Login";
  const auth = localStorage.getItem("token");

  useEffect(() => {
    auth && navigate("/dashboard");
  }, []);
  return (
    <div className="homediv">
      <Topbar text={loginbuttontext} link={"/login"} />
      <Middletext />
      <Screening />
      <div className="homepicture1">
        <img src={picture1} />
      </div>
      <div className="homepicture2">
        <img src={picture2} />
      </div>
      <HomeImage />
      <SalarySheet />
    </div>
  );
};

export default Home;
