import React from "react";
import { Link } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { useEffect } from "react";
import { getCandidates } from "../redux/actions/actions";

const Recruitment = () => {
  const dispatch = useDispatch();

  const { candidateData } = useSelector((state) => state.candidateData);

  useEffect(() => {
    dispatch(getCandidates());
  }, [dispatch]);

  console.log(candidateData);

  const sortedArray = candidateData;

  return (
    <div className="recruitmentcontent">
      <div className="toprecruitment">
        <span className="title">Recruitment Progress</span>
        <Link to="/resumerepository">
          <button className="link2">See All</button>
        </Link>
      </div>
      <div className="recruitmentdata">
        <table>
          <thead>
            <tr>
              <th className="heading">Full Name</th>
              <th className="heading">profession</th>
              <th className="heading">Status</th>
            </tr>
          </thead>

          <tbody>
            {sortedArray &&
              sortedArray.slice(0, 5).map((item, i) => {
                return (
                  <tr>
                    <td>
                      {item.firstname} {item.lastname}
                    </td>
                    <td>{item.technology}</td>
                    <td>
                      <span
                        className={
                          item.status == "hold"
                            ? "bluedot"
                            : item.status == "rejected"
                            ? "orangedot"
                            : "greendot"
                        }
                      ></span>
                      {item.status}
                    </td>
                  </tr>
                );
              })}
          </tbody>
        </table>
      </div>
      {/* <div className="recruitmentdata">
        <div className="list">
          <ul>
            <li>John Doe</li>
            <li>John Doe</li>
            <li>John Doe</li>
            <li>John Doe</li>
            <li>John Doe</li>
          </ul>
        </div>
        <div className="list">
          <ul>
            <li>UI designer</li>
            <li>PHP developer </li>
            <li>Node developer</li>
            <li>Node developer</li>
            <li>Node developer</li>
          </ul>
        </div>
        <div className="list ">
          <ul>
            <li>
              <span className="bluedot"></span>Hold
            </li>
            <li>
              <span className="orangedot"></span>Rejected
            </li>
            <li>
              <span className="greendot"></span>Selected
            </li>
            <li>
              <span className="orangedot"></span>Rejected
            </li>
            <li>
              <span className="greendot"></span>Selected
            </li>
          </ul>
        </div>
      </div> */}
    </div>
  );
};

export default Recruitment;
