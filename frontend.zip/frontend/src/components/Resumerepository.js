import React, { Component } from "react";
import Leftsidebar from "./Leftsidebar";
import Loggedintopbar from "./Loggedintopbar";
import { useSelector, useDispatch } from "react-redux";
import { getCandidates, deleteCandidate } from "../redux/actions/actions";
import { useEffect } from "react";
import Dropdown from "react-bootstrap/Dropdown";
import more from "../assets/more.png";
import { useState } from "react";
import PropTypes from "prop-types";
import Box from "@mui/material/Box";
import Collapse from "@mui/material/Collapse";
import IconButton from "@mui/material/IconButton";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import { KeyboardArrowUp, KeyboardArrowDown } from "@material-ui/icons";
import download from "../assets/download.png";
import Button from "react-bootstrap/Button";
import ReactPaginate from "react-paginate";
import { Link, useLocation } from "react-router-dom";
import axios from "axios";
import dummyprofilepic from "../assets/profile.png";
import Modal from "react-bootstrap/Modal";
import Form from "react-bootstrap/Form";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import upload from "../assets/upload.png";
import { backend_uri_local } from "../utils/constant";
import { Modal as AntModal } from "antd";
import { message } from "antd";

const Resumerepository = () => {
  const location = useLocation();
  const modal = location.state ? location.state.modal : false;
  const [currentPage, setCurrentPage] = useState(0);
  const itemsPerPage = 5;
  const startIndex = currentPage * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [imageSource, setImageSource] = useState(dummyprofilepic);
  const [resume, setResume] = useState(null);
  const [show, setShow] = useState(modal);
  const [isEditing, setIsEditing] = useState(false);
  const [error, setError] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [selectStatus, setSelectStatus] = useState("data");

  const handleOk = () => {
    // Add or update the data here
    message.success("Data added/updated successfully!", 4);
  };

  const [candidate, setCandidate] = useState({
    email: "",
    firstname: "",
    lastname: "",
    educationyear: "",
    education: "",
    experience: "",
    technology: "",
    skills: "",
    recentemployer: "",
    portfoliolink: "",
    status: "",
  });

  function handleResume(e) {
    setResume(e.target.files[0]);
  }
  const handleError = () => {
    // Add or update the data here

    message.error("Failed to add/update data!", 4);
  };

  const handleChange = (e) => {
    setCandidate({
      ...candidate,
      [e.target.name]: e.target.value,
    });
  };

  const handlecancel = () => {
    setShow(false);
    setCandidate({
      email: "",
      firstname: "",
      lastname: "",
      educationyear: "",
      education: "",
      experience: "",
      technology: "",
      skills: "",
      recentemployer: "",
      portfoliolink: "",
      status: "",
    });
    setSelectedPhoto(dummyprofilepic);
    setImageSource(dummyprofilepic);
    setResume(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(isEditing);
    isEditing ? submiteditform() : submitsaveform();
    setIsEditing(false);
    // const birthDateArray = String(birthDate).split(" ");
    // const dob =
    //   birthDateArray[2] + " " + birthDateArray[1] + " " + birthDateArray[3];
    // const joinDateArray = String(joinDate).split(" ");
    // const doj =
    //   joinDateArray[2] + " " + joinDateArray[1] + " " + joinDateArray[3];
  };

  const submitsaveform = () => {
    const candidatedata = {
      ...candidate,
      // dob: dob,
      // doj: doj,
      image: selectedPhoto,
    };

    let formData = new FormData();

    formData.append("firstname", candidate.firstname);
    formData.append("lastname", candidate.lastname);
    formData.append("technology", candidate.technology);
    formData.append("email", candidate.email);
    formData.append("education", candidate.education);
    formData.append("educationyear", candidate.educationyear);
    formData.append("skills", candidate.skills);
    formData.append("experience", candidate.experience);
    formData.append("recentemployer", candidate.recentemployer);
    formData.append("portfoliolink", candidate.portfoliolink);
    formData.append("image", selectedPhoto);
    formData.append("resumes", resume);
    formData.append("status", candidate.status);

    console.log(candidatedata);
    axios
      .post(`${backend_uri_local}/candidate`, formData)
      .then(() => {
        dispatch(getCandidates());
        setShow(false);
        setCandidate({
          email: "",
          firstname: "",
          lastname: "",
          educationyear: "",
          education: "",
          experience: "",
          technology: "",
          skills: "",
          recentemployer: "",
          portfoliolink: "",
          status: "",
        });
        setImageSource(dummyprofilepic);
        setSelectedPhoto(null);
        setResume(null);
        handleOk();
      })
      .catch((error) => {
        setError(true);
        setErrorMsg(error.data.msg);
        handleError();
      });
  };

  const submiteditform = () => {
    let formData = new FormData();
    formData.append("firstname", candidate.firstname);
    formData.append("lastname", candidate.lastname);
    formData.append("technology", candidate.technology);
    formData.append("email", candidate.email);
    formData.append("education", candidate.education);
    formData.append("educationyear", candidate.educationyear);
    formData.append("skills", candidate.skills);
    formData.append("experience", candidate.experience);
    formData.append("recentemployer", candidate.recentemployer);
    formData.append("portfoliolink", candidate.portfoliolink);
    formData.append("image", selectedPhoto);
    formData.append("resumes", resume);
    formData.append("status", candidate.status);

    axios
      .put(`${backend_uri_local}/employees`, formData)
      .then(() => {
        dispatch(getCandidates());
        setShow(false);
        setCandidate({
          email: "",
          firstname: "",
          lastname: "",
          educationyear: "",
          education: "",
          experience: "",
          technology: "",
          skills: "",
          recentemployer: "",
          portfoliolink: "",
          status: "",
        });

        setImageSource(dummyprofilepic);
        setSelectedPhoto(null);
        setIsEditing(false);
        setResume(null);
        handleOk();
      })
      .catch((error) => {
        setError(true);
        console.log(error);

        setErrorMsg(error.message);
        handleError();
      });
  };

  function handlePhoto(e) {
    setSelectedPhoto(e.target.files[0]);
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = () => {
      setImageSource(reader.result);
    };

    reader.readAsDataURL(file);
  }

  function handleShow(breakpoint) {
    setShow(true);
  }

  const handleStatusChange = (e) => {
    console.log(e.target.value);
    setSelectStatus(e.target.value);
  };

  const { candidateData } = useSelector((state) => state.candidateData);

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getCandidates());
  }, [dispatch]);

  const slicedData =
    candidateData &&
    candidateData
      .filter((i) => i.status == selectStatus || selectStatus == "data")
      .slice(startIndex, endIndex);
  // console.log("slicedData", slicedData);
  const [open, setOpen] = useState(false);

  const addnew = () => {
    setCandidate({
      email: "",
      firstname: "",
      lastname: "",
      educationyear: "",
      education: "",
      experience: "",
      technology: "",
      skills: "",
      recentemployer: "",
      portfoliolink: "",
      status: "",
    });
    setSelectedPhoto(dummyprofilepic);
    setImageSource(dummyprofilepic);
    setResume(null);

    handleShow();
  };

  return (
    <div className="resumerepositorymain">
      <div className="resumerepositoryleftside">
        <Leftsidebar />
      </div>
      <div className="resumerepositoryrightside">
        <div>
          <Loggedintopbar text="Resume repository" />
        </div>
        <div className="statusbutton">
          <div className="statusdiv">
            <Form.Select
              onChange={handleStatusChange}
              name="selectstatus"
              aria-label="Default select example"
              className="myselectclass"
            >
              <option value="data">Status</option>

              <option value="hold">Hold</option>
              <option value="rejected">Rejected</option>
              <option value="selected">Selected</option>
            </Form.Select>
          </div>
          <div className="addbuttonrr">
            <Link>
              <Button onClick={addnew} className="linkRR">
                + Add New
              </Button>
            </Link>
          </div>
        </div>
        <div className="tableRR">
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell />
                  <TableCell>Name</TableCell>
                  <TableCell>Email</TableCell>
                  <TableCell>Technology</TableCell>
                  <TableCell>Education Year</TableCell>
                  <TableCell>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {candidateData
                  ? slicedData.map((data) => (
                      <Row1 key={data.email} data={data} />
                    ))
                  : null}
              </TableBody>
            </Table>
          </TableContainer>
          <ReactPaginate
            pageCount={Math.ceil(
              candidateData &&
                candidateData.filter(
                  (i) => i.status == selectStatus || selectStatus == "data"
                ).length / itemsPerPage
            )}
            onPageChange={({ selected }) => setCurrentPage(selected)}
            containerClassName={"pagination"}
            pageClassName={"page-item"}
            pageLinkClassName={"page-link"}
            previousClassName={"page-item"}
            previousLinkClassName={"page-link"}
            nextClassName={"page-item"}
            nextLinkClassName={"page-link"}
            disabledClassName={"disabled"}
            activeClassName={"active"}
            previousLabel={"<"}
            nextLabel={">"}
          />
        </div>
        <Modal className="modal-lg" show={show} onHide={() => setShow(false)}>
          <Modal.Header closeButton>
            <Modal.Title id="example-custom-modal-styling-title">
              Add Candidate
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <h5>General Information</h5>
            <div className="mt-5">
              <Form onSubmit={handleSubmit} encType="multipart/form-data">
                <div className="mt-4 ms-4 profilepicupload">
                  <img src={imageSource} alt="Preview" />
                  <Button
                    onClick={() => document.getElementById("fileInput").click()}
                    className="uploadbutton"
                  >
                    Upload Photo
                  </Button>
                  <Form.Control
                    name="image"
                    type="file"
                    accept=".png, .jpg, .jpeg"
                    onChange={handlePhoto}
                    style={{ display: "none" }}
                    id="fileInput"
                  ></Form.Control>
                </div>

                <Row className="mt-3">
                  <Col>
                    <Form.Control
                      name="firstname"
                      value={candidate.firstname}
                      onChange={handleChange}
                      placeholder="First name"
                      required
                    />
                  </Col>
                  <Col>
                    <Form.Control
                      name="lastname"
                      value={candidate.lastname}
                      onChange={handleChange}
                      placeholder="Last name"
                      required
                    />
                  </Col>

                  <Col>
                    <Form.Select
                      name="technology"
                      className="form-control"
                      aria-label="position"
                      onChange={handleChange}
                      value={candidate.position}
                      required
                    >
                      <option value="">Job Title</option>
                      <option value="UX/UI Developer">UX/UI Developer</option>
                      <option value="Node Developer">Node Developer</option>
                      <option value="MERN developer">MERN developer</option>
                      <option value="React developer">React developer</option>
                      <option value="PHP developer">PHP developer</option>
                      <option value="Wordpress developer">
                        Wordpress developer
                      </option>
                      <option value="Data analyst">Data analyst</option>
                      <option value="Data engineer">Data engineer</option>
                    </Form.Select>
                  </Col>
                </Row>
                <Row className="mt-3">
                  <Col>
                    <Form.Control
                      name="email"
                      onChange={handleChange}
                      value={candidate.email}
                      placeholder="Email"
                      required
                    />
                  </Col>

                  <Col>
                    <Form.Control
                      name="education"
                      value={candidate.education}
                      onChange={handleChange}
                      placeholder="Education"
                      required
                    />
                  </Col>
                  <Col>
                    <Form.Control
                      name="educationyear"
                      value={candidate.educationyear}
                      onChange={handleChange}
                      placeholder="Education Year"
                      required
                    />
                  </Col>
                </Row>
                <h3 className="ciNE mt-5 ms-3">Technical Information</h3>
                <Row className="ms-0">
                  <Col>
                    <Form.Control
                      name="skills"
                      value={candidate.skills}
                      onChange={handleChange}
                      placeholder="Skills"
                      required
                    />
                  </Col>
                </Row>
                <h3 className="ciNE mt-5 ms-3">Candidate Experience</h3>
                <Row className="mt-3">
                  <Col>
                    <Form.Control
                      name="experience"
                      value={candidate.experience}
                      onChange={handleChange}
                      placeholder="Experience"
                      required
                    />
                  </Col>

                  <Col>
                    <Form.Control
                      name="recentemployer"
                      value={candidate.recentemployer}
                      onChange={handleChange}
                      placeholder="Recent Employer"
                      required
                    />
                  </Col>

                  <Col>
                    <Form.Control
                      name="portfoliolink"
                      value={candidate.portfoliolink}
                      onChange={handleChange}
                      placeholder="Portfolio Link"
                      required
                    />
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Select
                      name="status"
                      className="form-control"
                      aria-label="position"
                      onChange={handleChange}
                      value={candidate.status}
                      required
                    >
                      <option value="">Status</option>
                      <option value="hold">Hold</option>
                      <option value="rejected">Rejected</option>
                      <option value="selected">Selected</option>
                    </Form.Select>
                  </Col>
                  <Col></Col>
                </Row>
                <div>
                  <Button
                    onClick={() =>
                      document.getElementById("fileInput2").click()
                    }
                    className="uploadresume"
                  >
                    <img src={upload} />
                    {"    "} Upload resume
                  </Button>
                  <Form.Control
                    name="resumes"
                    type="file"
                    accept=".pdf, .docx, .doc"
                    onChange={handleResume}
                    style={{ display: "none" }}
                    id="fileInput2"
                  ></Form.Control>
                </div>
                <div className="addnewemployeebuttons mt-5">
                  <Button onClick={handlecancel} className="cancelbutton">
                    Cancel
                  </Button>

                  <Button type="submit" className="savebutton">
                    Save
                  </Button>
                </div>
                {error ? <div>{errorMsg}</div> : null}
              </Form>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    </div>
  );
};

const Row1 = ({ data }) => {
  const location = useLocation();
  const modal = location.state ? location.state.modal : false;
  const [open, setOpen] = useState(false);
  const [error, setError] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [show, setShow] = useState(modal);
  const [isEditing, setIsEditing] = useState(false);
  const [resume, setResume] = useState(null);
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [imageSource, setImageSource] = useState(dummyprofilepic);

  const [candidate, setCandidate] = useState({
    email: "",
    firstname: "",
    lastname: "",
    educationyear: "",
    education: "",
    experience: "",
    technology: "",
    skills: "",
    recentemployer: "",
    portfoliolink: "",
    status: "",
  });
  const dispatch = useDispatch();

  const handleOk = () => {
    // Add or update the data here
    message.success("Data added/updated successfully!", 4);
  };

  const handleError = () => {
    // Add or update the data here

    message.error("Failed to add/update data!", 4);
  };

  const modalHandleDelete = (dId) => {
    AntModal.confirm({
      title: "Are you sure you want to delete this item?",
      okText: "Yes",
      okType: "danger",
      cancelText: "No",

      onOk() {
        deleteHandler(dId);
      },
    });
  };

  const deleteHandler = (e) => {
    dispatch(deleteCandidate(e));
    handleOk();
  };

  const handleEdit = (e) => {
    console.log("hello");

    setIsEditing(true);

    setShow(true);

    setCandidate({
      email: data.email,
      firstname: data.firstname,
      lastname: data.lastname,
      image: data.image,
      educationyear: data.educationyear,
      education: data.education,
      experience: data.experience,
      technology: data.technology,
      skills: data.skills,
      recentemployer: data.recentemployer,
      portfoliolink: data.portfoliolink,
      status: data.status,
    });
    setImageSource(data.image);
    setSelectedPhoto(data.image);
    setResume(data.resumes);
  };

  function handleResume(e) {
    setResume(e.target.files[0]);
  }

  const handleChange = (e) => {
    setCandidate({
      ...candidate,
      [e.target.name]: e.target.value,
    });
  };

  const handlecancel = () => {
    setShow(false);
    setCandidate({
      email: "",
      firstname: "",
      lastname: "",
      educationyear: "",
      education: "",
      experience: "",
      technology: "",
      skills: "",
      recentemployer: "",
      portfoliolink: "",
      status: "",
    });
    setSelectedPhoto(dummyprofilepic);
    setImageSource(dummyprofilepic);
    setResume(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(isEditing);
    isEditing ? submiteditform() : submitsaveform();
    setIsEditing(false);
    // const birthDateArray = String(birthDate).split(" ");
    // const dob =
    //   birthDateArray[2] + " " + birthDateArray[1] + " " + birthDateArray[3];
    // const joinDateArray = String(joinDate).split(" ");
    // const doj =
    //   joinDateArray[2] + " " + joinDateArray[1] + " " + joinDateArray[3];
  };

  const submitsaveform = () => {
    const candidatedata = {
      ...candidate,
      // dob: dob,
      // doj: doj,
      image: selectedPhoto,
    };

    let formData = new FormData();

    formData.append("firstname", candidate.firstname);
    formData.append("lastname", candidate.lastname);
    formData.append("technology", candidate.technology);
    formData.append("email", candidate.email);
    formData.append("education", candidate.education);
    formData.append("educationyear", candidate.educationyear);
    formData.append("skills", candidate.skills);
    formData.append("experience", candidate.experience);
    formData.append("recentemployer", candidate.recentemployer);
    formData.append("portfoliolink", candidate.portfoliolink);
    formData.append("image", selectedPhoto);
    formData.append("resumes", resume);
    formData.append("status", candidate.status);

    console.log(candidatedata);
    axios
      .post(`${backend_uri_local}/candidate`, formData)
      .then(() => {
        dispatch(getCandidates());
        setShow(false);
        setCandidate({
          email: "",
          firstname: "",
          lastname: "",
          educationyear: "",
          education: "",
          experience: "",
          technology: "",
          skills: "",
          recentemployer: "",
          portfoliolink: "",
          status: "",
        });
        setImageSource(dummyprofilepic);
        setSelectedPhoto(null);
        setResume(null);
        handleOk();
      })
      .catch((error) => {
        setError(true);
        setErrorMsg(error.data.msg);
        handleError();
      });
  };

  const submiteditform = () => {
    let formData = new FormData();
    formData.append("firstname", candidate.firstname);
    formData.append("lastname", candidate.lastname);
    formData.append("technology", candidate.technology);
    formData.append("email", candidate.email);
    formData.append("education", candidate.education);
    formData.append("educationyear", candidate.educationyear);
    formData.append("skills", candidate.skills);
    formData.append("experience", candidate.experience);
    formData.append("recentemployer", candidate.recentemployer);
    formData.append("portfoliolink", candidate.portfoliolink);
    formData.append("image", selectedPhoto);
    formData.append("resumes", resume);
    formData.append("status", candidate.status);

    axios
      .put(`${backend_uri_local}/candidates`, formData)
      .then(() => {
        dispatch(getCandidates());
        setShow(false);
        setCandidate({
          email: "",
          firstname: "",
          lastname: "",
          educationyear: "",
          education: "",
          experience: "",
          technology: "",
          skills: "",
          recentemployer: "",
          portfoliolink: "",
          status: "",
        });

        setImageSource(dummyprofilepic);
        setSelectedPhoto(null);
        setIsEditing(false);
        setResume(null);
        handleOk();
      })
      .catch((error) => {
        setError(true);
        console.log(error);

        setErrorMsg(error.message);
        handleError();
      });
  };

  function handlePhoto(e) {
    setSelectedPhoto(e.target.files[0]);
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = () => {
      setImageSource(reader.result);
    };

    reader.readAsDataURL(file);
  }

  function handleShow(breakpoint) {
    setShow(true);
  }

  const { candidateData } = useSelector((state) => state.candidateData);

  useEffect(() => {
    dispatch(getCandidates());
  }, [dispatch]);

  // console.log("slicedData", slicedData);

  const addnew = () => {
    setCandidate({
      email: "",
      firstname: "",
      lastname: "",
      educationyear: "",
      education: "",
      experience: "",
      technology: "",
      skills: "",
      recentemployer: "",
      portfoliolink: "",
      status: "",
    });
    setSelectedPhoto(dummyprofilepic);
    setImageSource(dummyprofilepic);
    setResume(null);

    handleShow();
  };

  return (
    <>
      {data && (
        <>
          <TableRow>
            <TableCell>
              <IconButton size="small" onClick={() => setOpen(!open)}>
                {open ? <KeyboardArrowUp /> : <KeyboardArrowDown />}
              </IconButton>
            </TableCell>
            <TableCell>
              {data.firstname} {data.lastname}
            </TableCell>
            <TableCell>{data.email}</TableCell>
            <TableCell>{data.technology}</TableCell>
            <TableCell>{data.educationyear}</TableCell>
            <TableCell>
              <Dropdown>
                <Dropdown.Toggle id="dropdown-basic">
                  <img src={more} />
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item
                    href="#/action-2"
                    onClick={() => handleEdit(data.email)}
                  >
                    Edit
                  </Dropdown.Item>
                  <Dropdown.Item
                    onClick={() => {
                      modalHandleDelete(data.email);
                    }}
                    href="#/action-3"
                  >
                    Delete{" "}
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </TableCell>
          </TableRow>
          <TableRow>
            <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
              <Collapse in={open} timeout="auto" unmountOnExit>
                <Box margin={1}>
                  <div className="expandrowdiv">
                    <div className="basicinfodiv">
                      <img src={data.image} />
                      <h4>
                        {data.firstname} {data.lastname}
                      </h4>
                      <p>{data.technology}</p>
                    </div>
                    <div className="educationdatadiv">
                      <table>
                        <tbody>
                          <tr>
                            <td className="bolddata">Education</td>
                            <td className="lightdata">{data.education}</td>
                          </tr>
                          <tr>
                            <td className="bolddata">Education year</td>
                            <td className="lightdata">{data.educationyear}</td>
                          </tr>
                          <tr>
                            <td className="bolddata">Email ID</td>
                            <td className="lightdata">{data.email}</td>
                          </tr>
                          <tr>
                            <td className="bolddata">Skills</td>
                            <td className="lightdata">{data.skills}</td>
                          </tr>

                          <tr>
                            <td className="bolddata">Experience</td>
                            <td className="lightdata"> {data.experience}</td>
                          </tr>
                          <tr>
                            <td className="bolddata">Recent Employer</td>
                            <td className="lightdata">{data.recentemployer}</td>
                          </tr>

                          <tr>
                            <td className="bolddata">Portfolio Link</td>
                            <td className="lightdata">{data.portfoliolink}</td>
                          </tr>

                          <tr>
                            <td className="bolddata">Status</td>
                            <td className="lightdata">{data.status}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    <div className="fullresumedownloaddiv">
                      {data.resumes !== "null" && (
                        <Link
                          to={data.resumes}
                          target="_blank"
                          download={data.resumes}
                        >
                          <Button className="downloadresumebutton">
                            <img src={download} /> Full Resume
                          </Button>
                        </Link>
                      )}
                    </div>
                  </div>
                </Box>
              </Collapse>
            </TableCell>
          </TableRow>
        </>
      )}

      <Modal className="modal-lg" show={show} onHide={() => setShow(false)}>
        <Modal.Header closeButton>
          <Modal.Title id="example-custom-modal-styling-title">
            Add Candidate
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <h5>General Information</h5>
          <div className="mt-5">
            <Form onSubmit={handleSubmit} encType="multipart/form-data">
              <div className="mt-4 ms-4 profilepicupload">
                <img src={imageSource} alt="Preview" />
                <Button
                  onClick={() => document.getElementById("fileInput").click()}
                  className="uploadbutton"
                >
                  Upload Photo
                </Button>
                <Form.Control
                  name="image"
                  type="file"
                  accept=".png, .jpg, .jpeg"
                  onChange={handlePhoto}
                  style={{ display: "none" }}
                  id="fileInput"
                ></Form.Control>
              </div>

              <Row className="mt-3">
                <Col>
                  <Form.Control
                    name="firstname"
                    value={candidate.firstname}
                    onChange={handleChange}
                    placeholder="First name"
                    required
                  />
                </Col>
                <Col>
                  <Form.Control
                    name="lastname"
                    value={candidate.lastname}
                    onChange={handleChange}
                    placeholder="Last name"
                    required
                  />
                </Col>

                <Col>
                  <Form.Select
                    name="technology"
                    className="form-control"
                    aria-label="position"
                    onChange={handleChange}
                    value={candidate.technology}
                    required
                  >
                    <option value="">Job Title</option>
                    <option value="UX/UI Developer">UX/UI Developer</option>
                    <option value="Node Developer">Node Developer</option>
                    <option value="MERN developer">MERN developer</option>
                    <option value="React developer">React developer</option>
                    <option value="PHP developer">PHP developer</option>
                    <option value="Wordpress developer">
                      Wordpress developer
                    </option>
                    <option value="Data analyst">Data analyst</option>
                    <option value="Data engineer">Data engineer</option>
                  </Form.Select>
                </Col>
              </Row>
              <Row className="mt-3">
                <Col>
                  <Form.Control
                    name="email"
                    onChange={handleChange}
                    value={candidate.email}
                    placeholder="Email"
                    required
                  />
                </Col>

                <Col>
                  <Form.Control
                    name="education"
                    value={candidate.education}
                    onChange={handleChange}
                    placeholder="Education"
                    required
                  />
                </Col>
                <Col>
                  <Form.Control
                    name="educationyear"
                    value={candidate.educationyear}
                    onChange={handleChange}
                    placeholder="Education Year"
                    required
                  />
                </Col>
              </Row>
              <h3 className="ciNE mt-5 ms-3">Technical Information</h3>
              <Row className="ms-0">
                <Col>
                  <Form.Control
                    name="skills"
                    value={candidate.skills}
                    onChange={handleChange}
                    placeholder="Skills"
                    required
                  />
                </Col>
              </Row>
              <h3 className="ciNE mt-5 ms-3">Candidate Experience</h3>
              <Row className="mt-3">
                <Col>
                  <Form.Control
                    name="experience"
                    value={candidate.experience}
                    onChange={handleChange}
                    placeholder="Experience"
                    required
                  />
                </Col>

                <Col>
                  <Form.Control
                    name="recentemployer"
                    value={candidate.recentemployer}
                    onChange={handleChange}
                    placeholder="Recent Employer"
                    required
                  />
                </Col>

                <Col>
                  <Form.Control
                    name="portfoliolink"
                    value={candidate.portfoliolink}
                    onChange={handleChange}
                    placeholder="Portfolio Link"
                    required
                  />
                </Col>
              </Row>

              <h3 className="ciNE mt-5 ms-3">Candidate Experience</h3>

              <Row>
                <Col>
                  <Form.Select
                    name="status"
                    className="form-control"
                    aria-label="position"
                    onChange={handleChange}
                    value={candidate.status}
                    required
                  >
                    <option value="">Status</option>
                    <option value="hold">Hold</option>
                    <option value="rejected">Rejected</option>
                    <option value="selected">Selected</option>
                  </Form.Select>
                </Col>
                <Col></Col>
              </Row>
              <div>
                <Button
                  onClick={() => document.getElementById("fileInput2").click()}
                  className="uploadresume"
                >
                  <img src={upload} />
                  {"    "} Upload resume
                </Button>
                <Form.Control
                  name="resumes"
                  type="file"
                  accept=".pdf, .docx, .doc"
                  onChange={handleResume}
                  style={{ display: "none" }}
                  id="fileInput2"
                ></Form.Control>
              </div>
              <div className="addnewemployeebuttons mt-5">
                <Button onClick={handlecancel} className="cancelbutton">
                  Cancel
                </Button>

                <Button type="submit" className="savebutton">
                  Save
                </Button>
              </div>
              {error ? <div>{errorMsg}</div> : null}
            </Form>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
};

export default Resumerepository;
