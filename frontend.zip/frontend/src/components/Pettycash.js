import React from "react";
import Leftsidebar from "./Leftsidebar";
import Loggedintopbar from "./Loggedintopbar";
import { Link } from "react-router-dom";
import Button from "react-bootstrap/Button";
import upload from "../assets/upload.png";
import fileupload from "../assets/fileupload.png";

const Pettycash = () => {
  return (
    <div className="pettycashmain">
      <div className="leftsidebarpettycash">
        <Leftsidebar />
      </div>
      <div className="pettycashright">
        <div>
          <Loggedintopbar text="Petty Cash" />
        </div>
        <div>
          <Link>
            <Button className=" uploadpettycash">
              <img src={upload} />
              upload
            </Button>
          </Link>
        </div>
        <div className="pettycashimage">
          <img src={fileupload} />
        </div>
      </div>
    </div>
  );
};

export default Pettycash;
