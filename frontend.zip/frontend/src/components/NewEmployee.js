import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchProducts } from "../redux/actions/actions";
import Leftsidebar from "./Leftsidebar";
import { Link, useLocation } from "react-router-dom";
import { backend_uri_local } from "../utils/constant";
import { Modal as AntModal } from "antd";
import { message } from "antd";

import Moment from "react-moment";
import more from "../assets/more.png";

import dummyprofilepic from "../assets/profile.png";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Row from "react-bootstrap/Row";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import upload from "../assets/upload.png";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Dropdown from "react-bootstrap/Dropdown";
import Loggedintopbar from "./Loggedintopbar";
import ReactPaginate from "react-paginate";
import Alert from "react-bootstrap/Alert";

const NewEmployee = (props) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [isEditing, setIsEditing] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const location = useLocation();
  const [resume, setResume] = useState(null);

  const modal = location.state ? location.state.modal : false;

  const [imageSource, setImageSource] = useState(dummyprofilepic);

  const navigate = useNavigate();
  const [birthDate, setBirthDate] = useState(null);
  const [joinDate, setJoinDate] = useState(null);
  const [error, setError] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [currentPage, setCurrentPage] = useState(0);
  const itemsPerPage = 5;
  const startIndex = currentPage * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;

  const [employee, setEmployee] = useState({
    eid: "",
    position: "",
    department: "",
    email: "",
    contact: "",
    firstname: "",
    lastname: "",
    language: "",
    address: "",
  });

  const modalHandleDelete = (dId) => {
    AntModal.confirm({
      title: "Are you sure you want to delete this item?",
      okText: "Yes",
      okType: "danger",
      cancelText: "No",

      onOk() {
        deleteHandler(dId);
      },
    });
  };

  const handleError = () => {
    // Add or update the data here

    message.error("Failed to add/update data!", 4);
  };

  const handleOk = () => {
    // Add or update the data here
    message.success("Data added/updated successfully!", 4);
  };

  const submitsaveform = () => {
    const employeedata = {
      ...employee,
      // dob: dob,
      // doj: doj,
      image: selectedPhoto,
    };

    let formData = new FormData();
    formData.append("eid", employee.eid);
    formData.append("firstname", employee.firstname);
    formData.append("lastname", employee.lastname);
    formData.append("contact", employee.contact);
    formData.append("position", employee.position);
    formData.append("department", employee.department);
    formData.append("email", employee.email);
    formData.append("language", employee.language);
    formData.append("address", employee.address);
    formData.append("dob", birthDate);
    formData.append("doj", joinDate);
    formData.append("image", selectedPhoto);
    formData.append("resumes", resume);

    console.log(employeedata);
    axios
      .post(`${backend_uri_local}/employees`, formData)
      .then(() => {
        dispatch(fetchProducts());
        setShow(false);
        setEmployee({
          eid: "",
          position: "",
          department: "",
          email: "",
          contact: "",
          firstname: "",
          lastname: "",
          language: "",
          address: "",
        });
        setBirthDate(null);
        setJoinDate(null);
        setImageSource(dummyprofilepic);
        setSelectedPhoto(null);
        setResume(null);
        handleOk();
      })
      .catch((error) => {
        console.log(error);
        setError(true);
        setErrorMsg(
          error.response.data.message
            ? error.response.data.message
            : "Some error occured"
        );
        handleError();
      });
  };

  const submiteditform = () => {
    let formData = new FormData();
    formData.append("eid", employee.eid);
    formData.append("firstname", employee.firstname);
    formData.append("lastname", employee.lastname);
    formData.append("contact", employee.contact);
    formData.append("position", employee.position);
    formData.append("department", employee.department);
    formData.append("email", employee.email);
    formData.append("language", employee.language);
    formData.append("address", employee.address);
    formData.append("dob", birthDate);
    formData.append("doj", joinDate);
    formData.append("image", selectedPhoto);
    formData.append("resumes", resume);

    axios
      .put(`${backend_uri_local}/employees`, formData)
      .then(() => {
        dispatch(fetchProducts());
        setShow(false);
        setEmployee({
          eid: "",
          position: "",
          department: "",
          email: "",
          contact: "",
          firstname: "",
          lastname: "",
          language: "",
          address: "",
        });
        setBirthDate(null);
        setJoinDate(null);
        setImageSource(dummyprofilepic);
        setSelectedPhoto(null);
        setIsEditing(false);
        setResume(null);
        handleOk();
      })
      .catch((error) => {
        console.log(error);
        setError(true);

        setErrorMsg(error.message ? error.message : "Some error occured");
        handleError();
      });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(isEditing);
    isEditing ? submiteditform() : submitsaveform();
    setIsEditing(false);
    // const birthDateArray = String(birthDate).split(" ");
    // const dob =
    //   birthDateArray[2] + " " + birthDateArray[1] + " " + birthDateArray[3];
    // const joinDateArray = String(joinDate).split(" ");
    // const doj =
    //   joinDateArray[2] + " " + joinDateArray[1] + " " + joinDateArray[3];
  };

  const handleEdit = (e) => {
    setIsEditing(true);

    console.log(e);
    setShow(true);
    const edituser = data.filter((i) => i.eid == e);
    console.log(edituser);
    setEmployee({
      eid: edituser[0].eid,
      position: edituser[0].position,
      department: edituser[0].department,
      email: edituser[0].email,
      contact: edituser[0].contact,
      firstname: edituser[0].firstname,
      lastname: edituser[0].lastname,
      language: edituser[0].language,
      address: edituser[0].address,
      image: edituser[0].image,
    });
    setImageSource(edituser[0].image);
    setSelectedPhoto(edituser[0].image);
    setBirthDate(new Date(edituser[0].dob));
    setJoinDate(new Date(edituser[0].doj));
    setResume(edituser[0].resumes);
  };

  const addnew = () => {
    setEmployee({
      address: "",
      eid: "",
      position: "",
      firstname: "",
      lastname: "",
      position: "",
      email: "",
      department: "",
      language: "",
      contact: "",
      dob: "",
      doj: "",
    });
    setSelectedPhoto(dummyprofilepic);
    setImageSource(dummyprofilepic);
    setResume(null);
    setError(false);
    setErrorMsg("");
    setIsEditing(false);

    handleShow();
  };

  const handleopen = (e) => {
    navigate("/fullprofile", { state: { eid: e } });
  };

  const handleChange = (e) => {
    setEmployee({
      ...employee,
      [e.target.name]: e.target.value,
    });
  };

  const [show, setShow] = useState(modal);

  function handleShow(breakpoint) {
    setShow(true);
    setError(false);
    setErrorMsg("");
  }

  const deleteHandler = (e) => {
    console.log("hello", e);

    axios
      .delete(`${backend_uri_local}/employee/` + e)
      .then((res) => {
        dispatch(fetchProducts());
        handleOk();
        console.log(res);
      })
      .catch((error) => {
        setError(true);
        setErrorMsg(error.message);
        handleError();
      });
  };

  const handlecancel = () => {
    setShow(false);
    setEmployee({
      // eid: "",
      position: "",
      firstname: "",
      lastname: "",
      position: "",
      email: "",
      department: "",
      language: "",
      contact: "",
      dob: "",
      doj: "",
    });
    setSelectedPhoto(dummyprofilepic);
    setImageSource(dummyprofilepic);
    setResume(null);
    setError(false);
    setErrorMsg("");
  };

  function handlePhoto(e) {
    setSelectedPhoto(e.target.files[0]);
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = () => {
      setImageSource(reader.result);
    };

    reader.readAsDataURL(file);
  }

  function handleResume(e) {
    setResume(e.target.files[0]);
  }

  const { data } = useSelector((state) => state.data);
  console.log("data", data);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchProducts());
  }, []);

  const slicedData =
    data && data.filter((i) => !i.dor).slice(startIndex, endIndex);

  return (
    <div className="newEmployee">
      <div className="leftbarNE">
        <Leftsidebar />
      </div>
      <div className="rightsideNE">
        <Loggedintopbar text="Employee Records" />
        <div>
          <Link>
            <Button onClick={addnew} className="linkNE">
              + Add New
            </Button>
          </Link>
        </div>
        <div className="tableNE">
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Eid</th>
                <th>Positions</th>
                <th>Date of Joining</th>

                <th>Email ID</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              {data
                ? slicedData
                    .filter((data) => !data.dor)
                    .map((data, i) => {
                      return (
                        <tr key={data.eid}>
                          <td
                            style={{ textAlign: "left" }}
                            onClick={() => handleopen(data.eid)}
                          >
                            {data.image && (
                              <img className="propicNE" src={data.image} />
                            )}
                            {data.firstname} {data.lastname}
                          </td>
                          <td onClick={() => handleopen(data.eid)}>
                            {" "}
                            {data.eid}
                          </td>
                          <td onClick={() => handleopen(data.eid)}>
                            {data.position}
                          </td>
                          <td onClick={() => handleopen(data.eid)}>
                            <Moment format="D MMM YYYY">{data.doj}</Moment>
                          </td>

                          <td onClick={() => handleopen(data.eid)}>
                            {data.email}
                          </td>
                          <td>
                            <Dropdown>
                              <Dropdown.Toggle id="dropdown-basic">
                                <img className="morepic" src={more} />
                              </Dropdown.Toggle>

                              <Dropdown.Menu>
                                <Dropdown.Item
                                  onClick={() => handleEdit(data.eid)}
                                  href="#/action-2"
                                >
                                  Edit
                                </Dropdown.Item>
                                <Dropdown.Item
                                  onClick={() => {
                                    modalHandleDelete(data.eid);
                                  }}
                                  href="#/action-3"
                                >
                                  Delete{" "}
                                </Dropdown.Item>
                              </Dropdown.Menu>
                            </Dropdown>
                          </td>
                        </tr>
                      );
                    })
                : null}
            </tbody>
          </table>

          <ReactPaginate
            pageCount={Math.ceil(
              data && data.filter((i) => !i.dor).length / itemsPerPage
            )}
            onPageChange={({ selected }) => setCurrentPage(selected)}
            containerClassName={"pagination"}
            pageClassName={"page-item"}
            pageLinkClassName={"page-link"}
            previousClassName={"page-item"}
            previousLinkClassName={"page-link"}
            nextClassName={"page-item"}
            nextLinkClassName={"page-link"}
            disabledClassName={"disabled"}
            activeClassName={"active"}
            previousLabel={"<"}
            nextLabel={">"}
          />
        </div>

        <Modal className="modal-lg" show={show} onHide={() => setShow(false)}>
          <Modal.Header closeButton>
            <Modal.Title id="example-custom-modal-styling-title">
              Add Employee
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <h5>General Information</h5>
            <div className="mt-5">
              <Form onSubmit={handleSubmit} encType="multipart/form-data">
                <div className="mt-4 ms-4 profilepicupload">
                  <img src={imageSource} alt="Preview" />
                  <Button
                    onClick={() => document.getElementById("fileInput").click()}
                    className="uploadbutton"
                  >
                    Upload Photo
                  </Button>
                  <Form.Control
                    name="image"
                    type="file"
                    accept=".png, .jpg, .jpeg"
                    onChange={handlePhoto}
                    style={{ display: "none" }}
                    id="fileInput"
                  ></Form.Control>
                </div>

                <Row className="mt-3">
                  <Col>
                    <Form.Control
                      name="eid"
                      value={employee.eid}
                      onChange={handleChange}
                      placeholder="Employee id"
                      required
                      disabled={isEditing ? true : false}
                    />
                  </Col>
                  <Col>
                    <Form.Control
                      name="firstname"
                      value={employee.firstname}
                      onChange={handleChange}
                      placeholder="First name"
                      required
                    />
                  </Col>
                  <Col>
                    <Form.Control
                      name="lastname"
                      value={employee.lastname}
                      onChange={handleChange}
                      placeholder="Last name"
                      required
                    />
                  </Col>
                </Row>
                <Row className="mt-3">
                  <Col>
                    <DatePicker
                      className="form-control"
                      selected={birthDate}
                      onChange={(birthDate) => setBirthDate(birthDate)}
                      peekNextMonth
                      showMonthDropdown
                      showYearDropdown
                      dropdownMode="select"
                      placeholderText="Date of Birth"
                      showIcon
                      required
                    />
                  </Col>

                  <Col>
                    <Form.Select
                      name="language"
                      onChange={handleChange}
                      value={employee.language}
                      className="form-control"
                      aria-label="Language"
                      required
                    >
                      <option value="">Language</option>
                      <option value="english">English</option>
                      <option value="hindi">Hindi</option>
                    </Form.Select>
                  </Col>
                  <Col>
                    <Form.Control
                      name="email"
                      onChange={handleChange}
                      value={employee.email}
                      placeholder="Email"
                      required
                    />
                  </Col>
                </Row>
                <h3 className="ciNE mt-5 ms-3">Contact Information</h3>
                <Row className="ms-0">
                  <Col>
                    <Form.Control
                      name="address"
                      onChange={handleChange}
                      value={employee.address}
                      placeholder="Address"
                      required
                    />
                  </Col>
                  <Col>
                    <Form.Control
                      name="contact"
                      onChange={handleChange}
                      value={employee.contact}
                      placeholder="Phone"
                      required
                    />
                  </Col>
                </Row>
                <h3 className="ciNE mt-5 ms-3">Employee Information</h3>
                <Row className="mt-3">
                  <Col>
                    <DatePicker
                      className="form-control"
                      placeholderText="Date of Joining"
                      showIcon
                      selected={joinDate}
                      onChange={(joinDate) => setJoinDate(joinDate)}
                      peekNextMonth
                      showMonthDropdown
                      showYearDropdown
                      dropdownMode="select"
                      required
                    />
                  </Col>

                  <Col>
                    <Form.Select
                      name="position"
                      className="form-control"
                      aria-label="Job Title"
                      onChange={handleChange}
                      value={employee.position}
                      required
                    >
                      <option value="">Job Title</option>
                      <option value="UX/UI Developer">UX/UI Developer</option>
                      <option value="Node Developer">Node Developer</option>
                      <option value="MERN developer">MERN developer</option>
                      <option value="React developer">React developer</option>
                      <option value="PHP developer">PHP developer</option>
                      <option value="Wordpress developer">
                        Wordpress developer
                      </option>
                      <option value="Data analyst">Data analyst</option>
                      <option value="Data engineer">Data engineer</option>
                    </Form.Select>
                  </Col>
                  <Col>
                    <Form.Control
                      name="department"
                      onChange={handleChange}
                      value={employee.department}
                      placeholder="Department"
                      required
                    />
                  </Col>
                </Row>
                <div>
                  <Button
                    onClick={() =>
                      document.getElementById("fileInput2").click()
                    }
                    className="uploadresume"
                  >
                    <img src={upload} />
                    {"    "} Upload resume
                  </Button>
                  <Form.Control
                    name="resumes"
                    type="file"
                    accept=".pdf, .docx, .doc"
                    onChange={handleResume}
                    style={{ display: "none" }}
                    id="fileInput2"
                  ></Form.Control>
                </div>
                <div className="addnewemployeebuttons mt-5">
                  <Button onClick={handlecancel} className="cancelbutton">
                    Cancel
                  </Button>

                  <Button type="submit" className="savebutton">
                    Save
                  </Button>
                </div>
                {error && (
                  <div className="mt-2" style={{ width: 300 }}>
                    {error ? <Alert variant="danger">{errorMsg}</Alert> : null}
                  </div>
                )}
              </Form>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    </div>
  );
};

export default NewEmployee;
