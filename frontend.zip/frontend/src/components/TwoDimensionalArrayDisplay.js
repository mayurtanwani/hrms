import React, { useEffect } from "react";
import Table from "react-bootstrap/Table";
import moment from "moment";

const TwoDimensionalArrayDisplay = ({
  array,
  employeeAttendance,
  holidays,
  setTotalDays,
  setTotalLeaves,
  setTotalHolidays,
  selectedPeriod,
  setEarlyLeaves,
  employee,
  setHalfDays,
}) => {
  console.log(employeeAttendance);
  console.log("hello");
  var totalDays = 0;
  var totalLeaves = 0;
  var totalHolidays = 0;
  var earlyLeaves = 0;
  var halfDays = 0;

  useEffect(() => {
    setTotalDays(totalDays);
    setTotalHolidays(totalHolidays);
    setTotalLeaves(totalLeaves);
    setHalfDays(halfDays);
    console.log("rendered");
    setEarlyLeaves(earlyLeaves);
  }, [selectedPeriod, employee]);
  return (
    <Table
      bordered
      style={{
        height: "470px",
        width: "730px",
        marginLeft: "30px",
        textAlign: "center",
        verticalAlign: "middle",
      }}
    >
      <tbody>
        {array.map((row, rowIndex) => (
          <tr key={rowIndex}>
            {row.map((element, columnIndex) => {
              if (element instanceof Date) {
                var elementdate = element.getDate();
                var elementmonth = element.getMonth();
                var elementyear = element.getFullYear();
                totalDays++;
              }
              const checkdate =
                employeeAttendance &&
                employeeAttendance.filter((i) => {
                  const date1 = new Date(i.date);
                  return (
                    date1.getDate() == elementdate &&
                    date1.getMonth() == elementmonth &&
                    date1.getFullYear() == elementyear
                  );
                });

              const checkHoliday =
                holidays &&
                holidays.filter(
                  (i) =>
                    i.date.datetime.day == elementdate &&
                    i.date.datetime.month - 1 == elementmonth &&
                    i.date.datetime.year == elementyear
                );

              if (checkHoliday && checkHoliday.length > 0) {
                totalHolidays++;
                if (checkdate && checkdate.length > 0) {
                  checkdate[0].status = checkHoliday[0].name;
                } else if (checkdate) {
                  checkdate.push({ status: checkHoliday[0].name });
                }
              }
              if (checkdate && checkdate.length > 0) {
                if (checkdate[0].status == "Absent") {
                  totalLeaves++;
                }
              }

              if (checkdate && checkdate.length > 0) {
                const startTime = moment(checkdate[0].starttime, "HH:mm");
                const endTime = moment(checkdate[0].endtime, "HH:mm");
                const diff = moment.duration(endTime.diff(startTime));
                const hours = diff.hours();
                const minutes = diff.minutes();
                // console.log("sdfdsfdsafa", startTime);
                // console.log(endTime);
                // console.log(diff);
                // console.log(hours);
                if (hours >= 8 && hours < 9) {
                  earlyLeaves++;
                }
              }

              if (checkdate && checkdate.length > 0) {
                const startTime = moment(checkdate[0].starttime, "HH:mm");
                const endTime = moment(checkdate[0].endtime, "HH:mm");
                const diff = moment.duration(endTime.diff(startTime));
                const hours = diff.hours();
                const minutes = diff.minutes();
                // console.log("sdfdsfdsafa", startTime);
                // console.log(endTime);
                // console.log(diff);
                // console.log(hours);
                if (hours > 5 && hours < 8) {
                  halfDays++;
                }
              }

              return (
                <td
                  style={{ height: "100px", width: "100px !important" }}
                  key={columnIndex}
                >
                  {element instanceof Date ? (
                    checkdate && checkdate.length > 0 ? (
                      <div
                        style={{
                          height: "100%",
                        }}
                      >
                        <div
                          className="d-flex justify-content-center align-items-center"
                          style={{
                            height: "50%",
                            width: "100%",
                          }}
                        >
                          {element.getDate()}
                        </div>
                        <div
                          className="d-flex justify-content-center align-items-center"
                          style={{
                            height: "50%",
                            width: "100%",
                            background:
                              checkdate[0].status === "Absent"
                                ? "#8FE5FF"
                                : checkdate[0].status === "Present"
                                ? "#A3CE8F"
                                : "#FAD6BE",
                            fontSize: "10px",
                            fontWeight: "500",
                          }}
                        >
                          {checkdate[0].status}
                        </div>
                      </div>
                    ) : (
                      <div
                        style={{
                          height: "100%",
                          width: "100%",
                        }}
                      >
                        <div
                          className="d-flex justify-content-center align-items-center"
                          style={{
                            height: "50%",
                            width: "100%",
                          }}
                        >
                          {element.getDate()}
                        </div>
                        <div
                          className="d-flex justify-content-center align-items-center"
                          style={{
                            height: "50%",
                            width: "100%",
                          }}
                        ></div>
                      </div>
                    )
                  ) : (
                    element
                  )}
                </td>
              );
            })}
          </tr>
        ))}
      </tbody>
    </Table>
  );
};

export default TwoDimensionalArrayDisplay;
