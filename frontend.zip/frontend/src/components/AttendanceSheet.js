import React from "react";
import { useEffect } from "react";
import Leftsidebar from "./Leftsidebar";
import Loggedintopbar from "./Loggedintopbar";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useState } from "react";
import { Link } from "react-router-dom";
import moment from "moment";
import Table from "react-bootstrap/Table";
import { useSelector, useDispatch } from "react-redux";
import { getAttendance } from "../redux/actions/actions";

const AttendanceSheet = () => {
  const [date, setDate] = useState(new Date());
  const today = new Date();
  const options = { day: "numeric", month: "long", year: "numeric" };
  const formattedDate = today.toLocaleDateString("en-US", options);
  console.log(date);
  const selectedMonth = date
    .toLocaleString("default", { month: "long" })
    .toLowerCase();
  console.log(selectedMonth);
  const date1 = new Date(date);
  const { attendanceData } = useSelector((state) => state.attendanceData);
  const dispatch = useDispatch();
  const monthYearString = date1.toLocaleString("default", {
    month: "long",
  });
  const numberOfDaysInMonth = new Date(
    date1.getFullYear(),
    date1.getMonth() + 1,
    0
  ).getDate();
  const monthDays = Array.from(
    { length: numberOfDaysInMonth },
    (_, i) => `${i + 1} ${monthYearString}`
  );

  const month = date.getMonth() + 1; // add 1 since getMonth() returns a zero-based index
  const year = date.getFullYear();
  const daysInMonth = new Date(year, month, 0).getDate();
  const daysArray = Array.from({ length: daysInMonth }, (_, i) => i + 1); // create array of all days in month

  console.log(attendanceData);

  useEffect(() => {
    dispatch(getAttendance());
  }, []);

  console.log(attendanceData);

  const filteredData =
    attendanceData &&
    attendanceData.allAttendance.filter((obj) => {
      const month = new Date(obj.date)
        .toLocaleString("default", { month: "long" })
        .toLowerCase();
      return month === selectedMonth;
    });

  console.log(filteredData);
  console.log(monthDays);

  // const result =
  //   filteredData &&
  //   filteredData.reduce((acc, obj) => {
  //     const { date, eid, name, status } = obj;
  //     const day = new Date(date).getDate();
  //     const month = new Date(date)
  //       .toLocaleString("default", { month: "short" })
  //       .toLowerCase();
  //     const key = `${day}${month}`;

  //     if (!acc[eid]) {
  //       acc[eid] = { eid, name };
  //     }

  //     acc[eid][key] = status;

  //     return acc;
  //   }, {});

  // console.log(result);

  const result =
    filteredData &&
    filteredData.reduce((acc, obj) => {
      const { date, eid, name, status } = obj;
      const day = new Date(date).getDate();
      const month = new Date(date)
        .toLocaleString("default", { month: "long" })
        .toLowerCase();
      const key = `${day}${month}`;

      if (!acc[eid]) {
        acc[eid] = { eid, name };
      }

      acc[eid][key] = status;

      return acc;
    }, {});

  // Get the number of days in the month
  const month2 = new Date(date);
  const daysInMonth2 = new Date(
    month2.getFullYear(),
    month2.getMonth() + 1,
    0
  ).getDate();

  // Create an array of all the days in the month
  const daysArray2 = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  // Loop over each object in the result and add the missing keys with "N/A" value
  result &&
    Object.values(result).forEach((obj) => {
      daysArray2.forEach((day) => {
        const month = new Date(date)
          .toLocaleString("default", { month: "long" })
          .toLowerCase();
        const key = `${day}${month}`;

        if (!obj[key]) {
          obj[key] = "N/A";
        }
      });
    });

  console.log(result);

  const dataArray = result && Object.values(result);
  console.log(dataArray);

  return (
    <div>
      <div className="inoutsheetdetailsmain d-flex">
        <div className="inoutsheetdetailsleft">
          <Leftsidebar />
        </div>
        <div className="inoutsheetdetailsright">
          <Loggedintopbar text="Attendance Sheet" />
          <div className="d-flex justify-content-between align-items-center mt-5 ps-5 pe-1">
            <div
              style={{
                fontFamily: "Poppins",
                fontWeight: "600",
                fontSize: "18px",
                lineHeight: "27px",
              }}
              className="d-flex align-items-center"
            >
              <div className="ms-2">{formattedDate}</div>
            </div>
            <div style={{ width: "200px" }}>
              <DatePicker
                selected={date}
                onChange={(date) => setDate(date)}
                dateFormat="MMMM yyyy"
                showMonthYearPicker
                monthsShown={1}
                showIcon
              />
            </div>
          </div>
          <div
            className="mt-5"
            style={{ overflowX: "auto", margin: "0 auto", width: "90%" }}
          >
            <Table>
              <thead>
                <tr>
                  <th style={{ minWidth: "140px" }}>E.ID</th>
                  <th style={{ minWidth: "140px" }}>Name</th>
                  {monthDays.map((day) => (
                    <th style={{ minWidth: "140px" }} key={day}>
                      {day}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {dataArray &&
                  dataArray.map((row) => (
                    <tr key={row.eid}>
                      <td>{row.eid}</td>
                      <td>{row.name}</td>
                      {monthDays.map((day) => (
                        <td
                          key={day}
                          className={
                            row[day.split(" ").join("").toLowerCase()] ==
                            "Present"
                              ? "presenttext"
                              : row[day.split(" ").join("").toLowerCase()] ==
                                "Absent"
                              ? "absenttext"
                              : ""
                          }
                        >
                          {row[day.split(" ").join("").toLowerCase()] || "N/A"}
                        </td>
                      ))}
                    </tr>
                  ))}
              </tbody>
            </Table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AttendanceSheet;
