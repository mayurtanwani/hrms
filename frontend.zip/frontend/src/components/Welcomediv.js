import React from 'react'
import dashboardimg from "../assets/dashboardimg.png"

const Welcomediv = () => {
  return (
    <div className='welcomediv'>
      <div className='welcometext'>
        <h3>Hello Sir/Mam!</h3>
        <p>HR Management system is an essential tool that helps organization manage their employees effectively</p>
      </div>
      <div className="dashboardimg">
      <img  src={dashboardimg}/>
      </div>
    </div>
  )
}

export default Welcomediv
