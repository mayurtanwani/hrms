import React, { useState, useEffect } from "react";
import Leftsidebar from "./Leftsidebar";
import Loggedintopbar from "./Loggedintopbar";
import { Link } from "react-router-dom";
import Button from "react-bootstrap/Button";
import { useSelector, useDispatch } from "react-redux";
import { fetchProducts } from "../redux/actions/actions";
import Dropdown from "react-bootstrap/Dropdown";
import more from "../assets/more.png";
import Modal from "react-bootstrap/Modal";
import dummyprofilepic from "../assets/profile.png";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Row from "react-bootstrap/Row";
import axios from "axios";
import { backend_uri_local } from "../utils/constant";
import Alert from "react-bootstrap/Alert";
import ReactPaginate from "react-paginate";
import { Modal as AntModal } from "antd";
import { message } from "antd";

const Salary = () => {
  const [error, setError] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [imageSource, setImageSource] = useState(dummyprofilepic);
  const [show, setShow] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const itemsPerPage = 5;
  const startIndex = currentPage * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;

  const [employee, setEmployee] = useState({
    eid: "",
    position: "",
    firstname: "",
    lastname: "",
    status: "",
    salary: "",
    annualpay: "",
  });

  const handleOk = () => {
    // Add or update the data here
    message.success("Data added/updated successfully!", 4);
  };

  const handleError = () => {
    // Add or update the data here

    message.error("Failed to add/update data!", 4);
  };

  const modalHandleDelete = (dId) => {
    AntModal.confirm({
      title: "Are you sure you want to delete this item?",
      okText: "Yes",
      okType: "danger",
      cancelText: "No",

      onOk() {
        deleteHandler(dId);
      },
    });
  };

  const handlecancel = () => {
    setShow(false);
    setEmployee({
      eid: "",
      position: "",
      firstname: "",
      lastname: "",
    });
    setSelectedPhoto(dummyprofilepic);
    setImageSource(dummyprofilepic);
    setError(false);
    setErrorMsg("");
  };

  const specialhandleChange = (e) => {
    setEmployee({
      ...employee,
      [e.target.name]: e.target.value,
    });
    setError(false);
    setErrorMsg("");
    axios
      .get(`${backend_uri_local}/employee/${e.target.value}`)
      .then((res) => {
        console.log(res);
        console.log(res.data);
        setEmployee({
          position: res.data.user.position,
          firstname: res.data.user.firstname,
          lastname: res.data.user.lastname,
          eid: res.data.user.eid,
          salary: "",
          annualpay: "",
          status: "",
        });

        setImageSource(res.data.user.image);
        setSelectedPhoto(res.data.user.image);
      })
      .catch((error) => {
        console.log(error);
        setError(true);
        setErrorMsg(error.response.data.msg);
        setEmployee({
          eid: "",
          position: "",
          firstname: "",
          lastname: "",
        });
        setImageSource(dummyprofilepic);
        setSelectedPhoto(dummyprofilepic);
      });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    isEditing ? submiteditform() : submitsaveform();
    setIsEditing(false);
    // const birthDateArray = String(birthDate).split(" ");
    // const dob =
    //   birthDateArray[2] + " " + birthDateArray[1] + " " + birthDateArray[3];
    // const joinDateArray = String(joinDate).split(" ");
    // const doj =
    //   joinDateArray[2] + " " + joinDateArray[1] + " " + joinDateArray[3];
  };

  const handleEdit = (e) => {
    setIsEditing(true);
    setShow(true);
    const edituser = data.filter((i) => i.eid == e);
    setEmployee({
      eid: edituser[0].eid,
      position: edituser[0].position,
      firstname: edituser[0].firstname,
      lastname: edituser[0].lastname,
      image: edituser[0].image,
      salary: edituser[0].salary ? edituser[0].salary : "",
      status: edituser[0].status ? edituser[0].status : "",
      annualpay: edituser[0].annualpay ? edituser[0].annualpay : "",
    });
    setImageSource(edituser[0].image);
    setSelectedPhoto(edituser[0].image);
  };

  const handleChange = (e) => {
    setEmployee({
      ...employee,
      [e.target.name]: e.target.value,
    });
  };
  // const handleSubmit = (e) => {
  //   e.preventDefault();
  //   console.log(employee);

  //   axios
  //     .put("http://localhost:8000/employees", employee)
  //     .then(() => {
  //       dispatch(fetchProducts());
  //       setShow(false);
  //       setEmployee({
  //         eid: "",
  //         position: "",
  //         email: "",
  //         contact: "",
  //         firstname: "",
  //         lastname: "",
  //       });
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //       setError(true);
  //       setErrorMsg(error.data.msg);
  //     });
  // };

  const submitsaveform = () => {
    let formData = new FormData();
    formData.append("eid", employee.eid);
    formData.append("firstname", employee.firstname);
    formData.append("lastname", employee.lastname);
    formData.append("position", employee.position);
    formData.append("salary", employee.salary);
    formData.append("annualpay", employee.annualpay);
    formData.append("status", employee.status);
    formData.append("image", selectedPhoto);

    axios
      .put(`${backend_uri_local}/employees`, formData)
      .then(() => {
        dispatch(fetchProducts());
        setShow(false);
        setEmployee({
          eid: "",
          position: "",
          firstname: "",
          lastname: "",
          salary: "",
          annualpay: "",
          status: "",
        });

        setImageSource(dummyprofilepic);
        setSelectedPhoto(null);
        handleOk();
      })
      .catch((error) => {
        setError(true);
        setErrorMsg(error.data.msg);
        handleError();
      });
  };

  const deleteHandler = (e) => {
    axios
      .delete(`${backend_uri_local}/employee/` + e)
      .then((res) => {
        dispatch(fetchProducts());
        handleOk();
      })
      .catch((error) => {
        setError(true);
        setErrorMsg(error.data.msg);
        handleError();
      });
  };

  const submiteditform = () => {
    let formData = new FormData();
    formData.append("eid", employee.eid);
    formData.append("firstname", employee.firstname);
    formData.append("lastname", employee.lastname);
    formData.append("position", employee.position);
    formData.append("image", selectedPhoto);
    formData.append("salary", employee.salary);
    formData.append("annualpay", employee.annualpay);
    formData.append("status", employee.status);

    axios
      .put(`${backend_uri_local}/employees`, formData)
      .then(() => {
        dispatch(fetchProducts());
        setShow(false);
        setEmployee({
          eid: "",
          position: "",
          firstname: "",
          lastname: "",
          salary: "",
          annualpay: "",
          status: "",
        });
        setImageSource(dummyprofilepic);
        setSelectedPhoto(null);
        setIsEditing(false);
        handleOk();
      })
      .catch((error) => {
        setError(true);
        setErrorMsg(error.data.msg);
        handleError();
      });
  };

  function handleShow(breakpoint) {
    setShow(true);
  }

  const handleaddnew = () => {
    setEmployee({
      eid: "",
      position: "",
      firstname: "",
      lastname: "",
      salary: "",
      annualpay: "",
      status: "",
    });

    setImageSource(dummyprofilepic);
    setSelectedPhoto(null);
    setIsEditing(false);

    handleShow();
  };

  function handlePhoto(e) {
    setSelectedPhoto(e.target.files[0]);
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = () => {
      setImageSource(reader.result);
    };

    reader.readAsDataURL(file);
  }

  const { data } = useSelector((state) => state.data);
  console.log(data);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchProducts());
  }, []);

  const slicedData = data && data.slice(startIndex, endIndex);

  return (
    <div className="salaryMain">
      <div className="leftsidebarsalary">
        <Leftsidebar />
      </div>
      <div className="rightsidesalary">
        <Loggedintopbar text="Salary sheet" />
        <div>
          <Link>
            <Button onClick={handleaddnew} className="linkSalary">
              + Add New
            </Button>
          </Link>
        </div>
        <div className="tableSalary">
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Eid</th>
                <th>Positions</th>
                <th>Status</th>
                <th>Salary</th>
                <th>Annual Pay</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody style={{ textAlign: "center" }}>
              {data
                ? slicedData
                    .filter((data) => data.salary)
                    .map((data) => {
                      return (
                        <tr key={data.eid}>
                          <td style={{ textAlign: "left !important" }}>
                            <img className="propicSalary" src={data.image} />
                            {"          "}
                            {data.firstname} {data.lastname}
                          </td>
                          <td>{data.eid}</td>
                          <td>{data.position}</td>
                          <td>{data.status ? data.status : ""}</td>
                          <td>{data.salary ? data.salary : ""}</td>
                          <td>{data.annualpay ? data.annualpay : ""}</td>
                          <td>
                            <Dropdown>
                              <Dropdown.Toggle id="dropdown-basic">
                                <img src={more} />
                              </Dropdown.Toggle>

                              <Dropdown.Menu>
                                <Dropdown.Item
                                  onClick={() => handleEdit(data.eid)}
                                  href="#/action-2"
                                >
                                  Edit
                                </Dropdown.Item>
                                <Dropdown.Item
                                  onClick={() => {
                                    modalHandleDelete(data.eid);
                                  }}
                                  href="#/action-3"
                                >
                                  Delete{" "}
                                </Dropdown.Item>
                              </Dropdown.Menu>
                            </Dropdown>
                          </td>
                        </tr>
                      );
                    })
                : null}
            </tbody>
          </table>

          <ReactPaginate
            pageCount={Math.ceil(
              slicedData && slicedData.length / itemsPerPage
            )}
            onPageChange={({ selected }) => setCurrentPage(selected)}
            containerClassName={"pagination"}
            pageClassName={"page-item"}
            pageLinkClassName={"page-link"}
            previousClassName={"page-item"}
            previousLinkClassName={"page-link"}
            nextClassName={"page-item"}
            nextLinkClassName={"page-link"}
            disabledClassName={"disabled"}
            activeClassName={"active"}
            previousLabel={"<"}
            nextLabel={">"}
          />
        </div>
        <Modal className="modal-lg" show={show} onHide={() => setShow(false)}>
          <Modal.Header closeButton>
            <Modal.Title id="example-custom-modal-styling-title">
              Add Employee
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <h5>General Information</h5>{" "}
            <Form onSubmit={handleSubmit}>
              <div className="mt-4 ms-4 profilepicupload">
                <img src={imageSource} alt="Preview" />

                <Button
                  onClick={() => document.getElementById("fileInput").click()}
                  className="uploadbutton"
                >
                  Upload Photo
                </Button>

                <Form.Control
                  type="file"
                  accept=".png, .jpg, .jpeg"
                  onChange={handlePhoto}
                  style={{ display: "none" }}
                  id="fileInput"
                ></Form.Control>
              </div>
              <div className="mt-5">
                <Row>
                  <Col>
                    {/* <Form.Control
                      name="eid"
                      value={employee.eid}
                      onChange={specialhandleChange}
                      placeholder="Employee id"
                      required
                    /> */}

                    <Form.Select
                      name="eid"
                      className="form-control"
                      aria-label="employeeid"
                      onChange={specialhandleChange}
                      value={employee.eid}
                      required
                    >
                      <option value="">Select Employee</option>
                      {data &&
                        data.map((item) => (
                          <option value={item.eid}>
                            {item.firstname} {item.lastname}{" "}
                          </option>
                        ))}
                    </Form.Select>
                  </Col>
                  <Col>
                    <Form.Control
                      name="firstname"
                      value={employee.firstname}
                      onChange={handleChange}
                      placeholder="First name"
                      required
                    />
                  </Col>
                  <Col>
                    <Form.Control
                      name="lastname"
                      value={employee.lastname}
                      onChange={handleChange}
                      placeholder="Last name"
                      required
                    />
                  </Col>
                </Row>

                <h3 className="ciNE mt-5 ms-3">Employee Information</h3>
                <Row className="mt-5">
                  <Col>
                    <Form.Select
                      name="position"
                      className="form-control"
                      aria-label="Job Title"
                      onChange={handleChange}
                      value={employee.position}
                      required
                    >
                      <option value="">Job Title</option>
                      <option value="UX/UI Developer">UX/UI Developer</option>
                      <option value="Node Developer">Node Developer</option>
                      <option value="MERN developer">MERN developer</option>
                      <option value="React developer">React developer</option>
                      <option value="PHP developer">PHP developer</option>
                      <option value="Wordpress developer">
                        Wordpress developer
                      </option>
                      <option value="Data analyst">Data analyst</option>
                      <option value="Data engineer">Data engineer</option>
                    </Form.Select>
                  </Col>

                  <Col>
                    <Form.Select
                      name="status"
                      className="form-control"
                      aria-label="Status"
                      onChange={handleChange}
                      value={employee.status}
                      required
                    >
                      <option value="">Status</option>
                      <option value="Training Period">Training Period</option>
                      <option value="Worker">Worker</option>
                    </Form.Select>
                  </Col>

                  <Col></Col>
                </Row>

                <h3 className="ciNE mt-5 ms-3">Salary Information</h3>

                <Row className="ms-0 mb-5">
                  <Col>
                    <Form.Control
                      name="salary"
                      onChange={handleChange}
                      value={employee.salary}
                      placeholder="Salary"
                      required
                    />
                  </Col>
                  <Col>
                    <Form.Control
                      name="annualpay"
                      onChange={handleChange}
                      value={employee.annualpay}
                      placeholder="Annual Pay"
                      required
                    />
                  </Col>
                  <Col></Col>
                </Row>

                <div className="addsalarybuttons mt-5">
                  <Button onClick={handlecancel} className="cancelbutton">
                    Cancel
                  </Button>

                  <Button type="submit" className="savebutton">
                    Save
                  </Button>
                </div>
                <div className="mt-2" style={{ width: 300 }}>
                  {error ? <Alert variant="danger">{errorMsg}</Alert> : null}
                </div>
              </div>
            </Form>
          </Modal.Body>
        </Modal>
      </div>
    </div>
  );
};

export default Salary;
