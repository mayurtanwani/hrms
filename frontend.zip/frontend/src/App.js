import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import Home from "./components/Home";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./components/Login";
import Register from "./components/Register";
import Dashboard from "./components/Dashboard";
import PrivateComponent from "./components/privateComponent";
import { Provider } from "react-redux";
import store from "./store";

import { ProSidebarProvider } from "react-pro-sidebar";
import NewEmployee from "./components/NewEmployee";
import OldEmployee from "./components/OldEmployee";
import Salary from "./components/Salary";
import Pettycash from "./components/Pettycash";
import Jobdescription from "./components/Jobdescription";
import Resumerepository from "./components/Resumerepository";
import Fullprofile from "./components/Fullprofile";
import Inoutsheet from "./components/Inoutsheet";
import InOutSheetDetails from "./components/InOutSheetDetails";
import AttendanceSheet from "./components/AttendanceSheet";
import Leaves from "./components/Leaves";

function App() {
  const newemployeemodal = false;
  return (
    <Provider store={store}>
      <div className="App">
        <BrowserRouter>
          <ProSidebarProvider>
            <Routes>
              <Route element={<PrivateComponent />}>
                <Route exact path="/dashboard" element={<Dashboard />}></Route>
                <Route
                  exact
                  path="/newemployee"
                  element={<NewEmployee />}
                ></Route>
                <Route
                  exact
                  path="/oldemployee"
                  element={<OldEmployee />}
                ></Route>

                <Route exact path="/salary" element={<Salary />}></Route>
                <Route exact path="/pettycash" element={<Pettycash />}></Route>
                <Route
                  exact
                  path="/jobdescription"
                  element={<Jobdescription />}
                ></Route>
                <Route
                  exact
                  path="/resumerepository"
                  element={<Resumerepository />}
                ></Route>
                <Route
                  exact
                  path="fullprofile"
                  element={<Fullprofile />}
                ></Route>
                <Route exact path="inoutsheet" element={<Inoutsheet />}></Route>
                <Route
                  exact
                  path="inoutsheetdetails"
                  element={<InOutSheetDetails />}
                ></Route>
                <Route
                  exact
                  path="attendancesheet"
                  element={<AttendanceSheet />}
                ></Route>
                <Route exact path="leaves" element={<Leaves />}></Route>
              </Route>
              <Route exact path="/" element={<Home />}></Route>
              <Route exact path="/login" element={<Login />}></Route>
              <Route exact path="/register" element={<Register />}></Route>
            </Routes>
          </ProSidebarProvider>
        </BrowserRouter>
      </div>
    </Provider>
  );
}

export default App;
