import { createStore, applyMiddleware } from "redux";
import { combineReducers } from "redux";
import {
  employeeReducer,
  candidateReducer,
  getAttendanceReducer,
} from "./redux/reducer/reducer";
import thunk from "redux-thunk";

const rootReducer = combineReducers({
  data: employeeReducer,
  candidateData: candidateReducer,
  attendanceData: getAttendanceReducer,
});

const initialState = {
  data: { employeeReducer },
  candidateData: { candidateReducer },
  attendanceData: { getAttendanceReducer },
};

const store = createStore(rootReducer, initialState, applyMiddleware(thunk));

export default store;
