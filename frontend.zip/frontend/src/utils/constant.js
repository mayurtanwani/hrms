// export const backend_uri_local = "http://localhost:8000";
export const backend_uri_local = "http://192.168.1.50:8000";
