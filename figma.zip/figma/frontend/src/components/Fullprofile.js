import React, { useState, useEffect } from "react";
import profilepic from "../assets/Profilephoto.png";
import edit from "../assets/Group 2412.png";
import { Link } from "react-router-dom";
import upload from "../assets/upload.png";
import Button from "react-bootstrap/Button";
import certificate from "../assets/Rectangle 62.png";
import DatePicker from "react-datepicker";
import { useLocation } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import axios from "axios";
import { backend_uri_local } from "../utils/constant";
import Moment from "react-moment";

const Fullprofile = () => {
  const location = useLocation();
  const id = location && location.state.eid;
  const handleEdit = location.state.handleEdit;

  const [singleEmployeeData, setSingleEmployeeData] = useState(null);

  useEffect(() => {
    axios
      .get(`${backend_uri_local}/employee/${id}`)
      .then((res) => setSingleEmployeeData(res.data))
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const newemployeemodal = true;
  const [toggleState, setToggleState] = useState(1);
  const toggleTab = (index) => {
    setToggleState(index);
  };

  const dataToSend = {
    name: "John",
    age: 30,
  };
  return (
    <div className="fullprofilemain">
      <div className="fullprofiletitle">
        <Link to="/newemployee">
          <h4> &lt; Full Employee Profile</h4>
        </Link>
      </div>
      {singleEmployeeData && (
        <>
          <div className="fullprofiledetails">
            <div className="fpimage">
              <img src={singleEmployeeData.user.image} />
            </div>
            <div className="fptable">
              <table>
                <thead>
                  <tr>
                    <th className="namefp">
                      {singleEmployeeData.user.firstname}{" "}
                      {singleEmployeeData.user.lastname}
                    </th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th className="jobtitlefp">
                      {singleEmployeeData.user.position}
                    </th>
                    <th></th>
                  </tr>
                  <tr>
                    <th className="detailsfp">Date of Join</th>

                    <th className="valuesfp">
                      <Moment format="D MMM YYYY">
                        {singleEmployeeData.user.doj}
                      </Moment>
                    </th>
                  </tr>
                  <tr>
                    <th className="detailsfp">Contact No.</th>
                    <th className="valuesfp">
                      {singleEmployeeData.user.contact}
                    </th>
                  </tr>
                  <tr>
                    <th className="detailsfp">Email </th>
                    <th className="valuesfp">
                      {singleEmployeeData.user.email}
                    </th>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="editbuttonfp">
              <div>
                <Link to="/newemployee">
                  <button>
                    <img src={edit} /> Edit
                  </button>
                </Link>
              </div>
            </div>
          </div>
          <div className="bloc-tabs">
            <button
              className={toggleState === 1 ? "tabs active-tabs" : "tabs"}
              onClick={() => toggleTab(1)}
            >
              Employee Information
            </button>
            <button
              className={toggleState === 2 ? "tabs active-tabs" : "tabs"}
              onClick={() => toggleTab(2)}
            >
              Payroll Details
            </button>
          </div>
          <div className="content-tabs">
            <div
              className={
                toggleState === 1 ? "content  active-content" : "content"
              }
            >
              <p>Employee Information</p>
              <table>
                <tbody>
                  <tr>
                    <td className="datanamefp">Employee ID</td>
                    <td className="datavaluefp">
                      {singleEmployeeData.user.eid}
                    </td>
                    <td className="datanamefp">Address</td>
                    <td className="datavaluefp">Indore</td>
                  </tr>
                  <tr>
                    <td className="datanamefp">Name</td>
                    <td className="datavaluefp">
                      {singleEmployeeData.user.firstname}{" "}
                      {singleEmployeeData.user.lastname}
                    </td>
                    <td className="datanamefp">Date Of Birth</td>
                    <td className="datavaluefp">
                      <Moment format="D MMM YYYY">
                        {singleEmployeeData.user.dob}
                      </Moment>
                    </td>
                  </tr>
                  <tr>
                    <td className="datanamefp">Position</td>
                    <td className="datavaluefp">
                      {singleEmployeeData.user.position}
                    </td>
                    <td className="datanamefp">Email ID</td>
                    <td className="datavaluefp">
                      {singleEmployeeData.user.email}
                    </td>
                  </tr>
                  <tr>
                    <td className="datanamefp">Country</td>
                    <td className="datavaluefp"> India</td>
                    <td className="datanamefp">Contact</td>
                    <td className="datavaluefp">
                      {singleEmployeeData.user.contact}
                    </td>
                  </tr>
                </tbody>
              </table>
              <div className="middledivbarfp">
                <div>
                  <h5>Attachments</h5>
                </div>
                <div>
                  <Link>
                    <Button className="uploadfp">
                      <img src={upload} />
                      upload
                    </Button>
                  </Link>
                </div>
              </div>

              <div className="allcertificatesfp">
                <div className="certificatefp">
                  <img src={certificate} />
                  <h6 className="h6fp">Offer Letter</h6>
                  <h6 className="h6fp2">Created 6-9-2022 </h6>
                </div>
                <div className="certificatefp">
                  <img src={certificate} />
                  <h6 className="h6fp">Experiece Letter</h6>
                  <h6 className="h6fp2">Created 6-9-2022 </h6>
                </div>
                <div className="certificatefp">
                  <img src={certificate} />
                  <h6 className="h6fp">Employee Letter</h6>
                  <h6 className="h6fp2">Created 6-9-2022 </h6>
                </div>
              </div>
            </div>

            <div
              className={
                toggleState === 2 ? "content  active-content" : "content"
              }
            >
              <p>Bank Details</p>
              <table>
                <tbody>
                  <tr>
                    <td className="datanamefp">A/c No.</td>
                    <td className="datavaluefp">8767876546</td>
                  </tr>
                  <tr>
                    <td className="datanamefp">IFSC Code</td>
                    <td className="datavaluefp">BKID0MG0429 </td>
                  </tr>
                  <tr>
                    <td className="datanamefp">Bank Name </td>
                    <td className="datavaluefp">Bank Of India</td>
                  </tr>
                  <tr>
                    <td className="datanamefp">Branch</td>
                    <td className="datavaluefp"> Indore</td>
                  </tr>
                </tbody>
              </table>

              <div className="middledivbarfp2">
                <div>
                  <h5>Salary</h5>
                </div>
                <div>
                  <DatePicker
                    className="form-control"
                    peekNextMonth
                    showMonthDropdown
                    showYearDropdown
                    dropdownMode="select"
                    placeholderText="January 2023"
                    showIcon
                    required
                  />
                </div>
              </div>
              <div className="fptablefp">
                <table>
                  <thead>
                    <tr>
                      <th>Eid</th>
                      <th>Name</th>
                      <th>Date</th>
                      <th>Basic Salary</th>
                      <th>Additions</th>
                      <th>Deductions</th>
                      <th>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1</td>
                      <td>Fay Hill</td>
                      <td>2-1-2023</td>
                      <td>15000</td>
                      <td>1000</td>
                      <td>00.00</td>
                      <td>16000</td>
                    </tr>
                    <tr>
                      <td>1</td>
                      <td>Fay Hill</td>
                      <td>2-1-2023</td>
                      <td>15000</td>
                      <td>1000</td>
                      <td>00.00</td>
                      <td>16000</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default Fullprofile;
