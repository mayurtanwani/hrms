import React from "react";
import { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchProducts } from "../redux/actions/actions";
import Leftsidebar from "./Leftsidebar";
import { Link } from "react-router-dom";
import Moment from "react-moment";
import more from "../assets/more.png";
import Modal from "react-bootstrap/Modal";
import dummyprofilepic from "../assets/profile.png";
import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Row from "react-bootstrap/Row";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Dropdown from "react-bootstrap/Dropdown";
import Loggedintopbar from "./Loggedintopbar";
import Alert from "react-bootstrap/Alert";
import { backend_uri_local } from "../utils/constant";
import ReactPaginate from "react-paginate";
import { Modal as AntModal } from "antd";
import { message } from "antd";

const OldEmployee = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [imageSource, setImageSource] = useState(dummyprofilepic);
  const navigate = useNavigate();

  const [show, setShow] = useState(false);
  function handleShow(breakpoint) {
    setShow(true);
  }

  const [error, setError] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [currentPage, setCurrentPage] = useState(0);
  const itemsPerPage = 5;
  const startIndex = currentPage * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;

  const handleSubmit = (e) => {
    e.preventDefault();

    console.log(isEditing);
    console.log("hello");
    isEditing ? submiteditform() : submitsaveform();
    setIsEditing(false);

    // const resignDateArray = String(resignDate).split(" ");
    // const dor =
    //   resignDateArray[2] + " " + resignDateArray[1] + " " + resignDateArray[3];

    // const employeedata = {
    //   ...employee,
    //   dor: dor,
    // };

    // console.log(dor);
  };

  const handleOk = () => {
    // Add or update the data here
    message.success("Data added/updated successfully!", 4);
  };

  const handleError = () => {
    // Add or update the data here

    message.error("Failed to add/update data!", 4);
  };

  const addnew = () => {
    setEmployee({
      eid: "",
      position: "",
      firstname: "",
      lastname: "",
      email: "",
      language: "",
      contact: "",
      status: "",
    });
    setSelectedPhoto(dummyprofilepic);
    setImageSource(dummyprofilepic);
    setIsEditing(false);

    handleShow();
  };

  const handlecancel = () => {
    setShow(false);
    setEmployee({
      eid: "",
      position: "",
      firstname: "",
      lastname: "",
      position: "",
      email: "",
      department: "",
      language: "",
      contact: "",
      dob: "",
      doj: "",
      status: "",
    });
    setSelectedPhoto(dummyprofilepic);
    setImageSource(dummyprofilepic);
    setError(false);
    setErrorMsg("");
  };

  const submitsaveform = () => {
    let formData = new FormData();
    formData.append("eid", employee.eid);
    formData.append("firstname", employee.firstname);
    formData.append("lastname", employee.lastname);
    formData.append("contact", employee.contact);
    formData.append("position", employee.position);
    formData.append("email", employee.email);
    formData.append("dor", resignDate);
    formData.append("image", selectedPhoto);
    formData.append("status", employee.status);

    console.log(formData);

    axios
      .put(`${backend_uri_local}/employees`, formData)
      .then(() => {
        dispatch(fetchProducts());
        setShow(false);
        setEmployee({
          eid: "",
          position: "",
          email: "",
          contact: "",
          firstname: "",
          lastname: "",
          status: "",
        });
        setResignDate(null);
        setImageSource(dummyprofilepic);
        setSelectedPhoto(null);
        handleOk();
      })
      .catch((error) => {
        console.log(error);
        setError(true);
        setErrorMsg(error.data.msg);
        handleError();
      });
  };

  const submiteditform = () => {
    let formData = new FormData();
    formData.append("eid", employee.eid);
    formData.append("firstname", employee.firstname);
    formData.append("lastname", employee.lastname);
    formData.append("contact", employee.contact);
    formData.append("position", employee.position);
    formData.append("dor", resignDate);
    formData.append("email", employee.email);
    formData.append("status", employee.status);
    formData.append("image", selectedPhoto);

    axios
      .put(`${backend_uri_local}/employees`, formData)
      .then(() => {
        dispatch(fetchProducts());
        setShow(false);
        setEmployee({
          eid: "",
          position: "",
          email: "",
          contact: "",
          firstname: "",
          lastname: "",
          status: "",
        });

        setResignDate(null);
        setImageSource(dummyprofilepic);
        setSelectedPhoto(null);
        setIsEditing(false);
        handleOk();
      })
      .catch((error) => {
        setError(true);
        console.log(error);
        console.log(error.data);
        setErrorMsg(error.data.msg);
        handleError();
      });
  };

  const deleteHandler = (e) => {
    axios
      .delete(`${backend_uri_local}/employee/` + e)
      .then((res) => {
        dispatch(fetchProducts());
        handleOk();
      })
      .catch((error) => {
        setError(true);
        setErrorMsg(error.data.msg);
        handleError();
      });
  };
  const { data } = useSelector((state) => state);
  console.log("data", data);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchProducts());
  }, []);

  const [resignDate, setResignDate] = useState(null);
  const [employee, setEmployee] = useState({
    eid: "",
    position: "",
    email: "",
    contact: "",
    firstname: "",
    lastname: "",
    status: "",
  });
  function handlePhoto(e) {
    setSelectedPhoto(e.target.files[0]);
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = () => {
      setImageSource(reader.result);
    };

    reader.readAsDataURL(file);
  }
  const handleChange = (e) => {
    setEmployee({
      ...employee,
      [e.target.name]: e.target.value,
    });
  };

  const specialhandleChange = (e) => {
    setEmployee({
      ...employee,
      [e.target.name]: e.target.value,
    });
    setError(false);
    setErrorMsg("");
    axios
      .get(`${backend_uri_local}/employee/${e.target.value}`)
      .then((res) => {
        console.log(res);
        console.log(res.data);
        setEmployee({
          position: res.data.user.position,
          email: res.data.user.email,
          contact: res.data.user.contact,
          firstname: res.data.user.firstname,
          lastname: res.data.user.lastname,
          eid: res.data.user.eid,
        });

        setImageSource(res.data.user.image);
        setSelectedPhoto(res.data.user.image);
      })
      .catch((error) => {
        console.log(error);
        setError(true);
        setErrorMsg(error.response.data.msg);
        setEmployee({
          eid: "",
          position: "",
          email: "",
          contact: "",
          firstname: "",
          lastname: "",
          status: "",
        });
        setImageSource(dummyprofilepic);
        setSelectedPhoto(dummyprofilepic);
      });
  };

  const modalHandleDelete = (dId) => {
    AntModal.confirm({
      title: "Are you sure you want to delete this item?",
      okText: "Yes",
      okType: "danger",
      cancelText: "No",

      onOk() {
        deleteHandler(dId);
      },
    });
  };

  const handleEdit = (e) => {
    setIsEditing(true);

    console.log(e);
    setShow(true);
    const edituser = data.data.filter((i) => i.eid == e);
    console.log(edituser);
    setEmployee({
      eid: edituser[0].eid,
      position: edituser[0].position,
      department: edituser[0].department,
      email: edituser[0].email,
      contact: edituser[0].contact,
      firstname: edituser[0].firstname,
      lastname: edituser[0].lastname,
      language: edituser[0].language,
      address: edituser[0].address,
      image: edituser[0].image,
      status: edituser[0].status,
    });
    setImageSource(edituser[0].image);
    setSelectedPhoto(edituser[0].image);
    setResignDate(new Date(edituser[0].dor));
  };

  const slicedData =
    data.data && data.data.filter((i) => i.dor).slice(startIndex, endIndex);

  return (
    <div className="oldEmployee">
      <div className="leftbarOE">
        <Leftsidebar />
      </div>
      <div className="rightsideOE">
        <Loggedintopbar text="Employee Records" />
        <div>
          <Link>
            <Button onClick={addnew} className="linkNE">
              + Add New
            </Button>
          </Link>
        </div>
        <div className="tableOE">
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Eid</th>
                <th>Positions</th>
                <th>Date of Resigining </th>
                <th>Status</th>
                <th>Email ID</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody style={{ textAlign: "center" }}>
              {data.data
                ? slicedData
                    .filter((data) => data.dor)
                    .map((data, i) => {
                      return (
                        <tr key={i}>
                          <td style={{ textAlign: "left" }}>
                            {data.image && (
                              <img className="propicOE" src={data.image} />
                            )}
                            {data.firstname} {data.lastname}
                          </td>

                          <td>{data.eid}</td>
                          <td>{data.position}</td>
                          <td>
                            <Moment format="D MMM YYYY">{data.dor}</Moment>
                          </td>
                          <td>{data.status}</td>
                          <td>{data.email}</td>

                          <td>
                            <Dropdown>
                              <Dropdown.Toggle id="dropdown-basic">
                                <img src={more} />
                              </Dropdown.Toggle>

                              <Dropdown.Menu>
                                <Dropdown.Item
                                  onClick={() => handleEdit(data.eid)}
                                  href="#/action-2"
                                >
                                  Edit
                                </Dropdown.Item>
                                <Dropdown.Item
                                  onClick={() => {
                                    modalHandleDelete(data.eid);
                                  }}
                                  href="#/action-3"
                                >
                                  Delete{" "}
                                </Dropdown.Item>
                              </Dropdown.Menu>
                            </Dropdown>
                          </td>
                        </tr>
                      );
                    })
                : null}
            </tbody>
          </table>
          <ReactPaginate
            pageCount={Math.ceil(
              data.data && data.data.filter((i) => i.dor).length / itemsPerPage
            )}
            onPageChange={({ selected }) => setCurrentPage(selected)}
            containerClassName={"pagination"}
            pageClassName={"page-item"}
            pageLinkClassName={"page-link"}
            previousClassName={"page-item"}
            previousLinkClassName={"page-link"}
            nextClassName={"page-item"}
            nextLinkClassName={"page-link"}
            disabledClassName={"disabled"}
            activeClassName={"active"}
            previousLabel={"<"}
            nextLabel={">"}
          />
        </div>
        <Modal className="modal-lg" show={show} onHide={() => setShow(false)}>
          <Modal.Header closeButton>
            <Modal.Title id="example-custom-modal-styling-title">
              Add Employee
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <h5>General Information</h5>
            <Form onSubmit={handleSubmit} encType="multipart/form-data">
              <div className="mt-4 ms-4 profilepicupload">
                <img src={imageSource} alt="Preview" />
                <Button
                  onClick={() => document.getElementById("fileInput").click()}
                  className="uploadbutton"
                >
                  Upload Photo
                </Button>
                <Form.Control
                  type="file"
                  name="photo"
                  accept=".png, .jpg, .jpeg"
                  onChange={handlePhoto}
                  style={{ display: "none" }}
                  id="fileInput"
                ></Form.Control>
              </div>
              <div className="mt-5">
                <Row>
                  <Col>
                    {/* <Form.Control
                      name="eid"
                      value={employee.eid}
                      onChange={specialhandleChange}
                      placeholder="Employee id"
                      required
                    /> */}
                    <Form.Select
                      name="eid"
                      className="form-control"
                      aria-label="employeeid"
                      onChange={specialhandleChange}
                      value={employee.eid}
                      required
                    >
                      <option value="">Select Employee</option>
                      {data.data &&
                        data.data.map((item) => (
                          <option value={item.eid}>
                            {item.firstname} {item.lastname}{" "}
                          </option>
                        ))}
                    </Form.Select>
                  </Col>
                  <Col>
                    <Form.Control
                      name="firstname"
                      value={employee.firstname}
                      onChange={handleChange}
                      placeholder="First name"
                      required
                    />
                  </Col>
                  <Col>
                    <Form.Control
                      name="lastname"
                      value={employee.lastname}
                      onChange={handleChange}
                      placeholder="Last name"
                      required
                    />
                  </Col>
                </Row>
                <Row className="mt-5">
                  <Col>
                    <Form.Control
                      name="email"
                      onChange={handleChange}
                      value={employee.email}
                      placeholder="Email"
                      required
                    />
                  </Col>
                </Row>

                <h3 className="ciNE mt-5 ms-3">Contact Information</h3>

                <Row className="ms-0 mb-5">
                  <Col>
                    <Form.Control
                      name="contact"
                      onChange={handleChange}
                      value={employee.contact}
                      placeholder="Phone"
                      required
                    />
                  </Col>
                </Row>

                <h3 className="ciNE mt-5 ms-3">Employee Information</h3>

                <Row className="mt-3">
                  <Col>
                    <DatePicker
                      className="form-control"
                      placeholderText="Date of Resigning"
                      showIcon
                      selected={resignDate}
                      onChange={(resignDate) => setResignDate(resignDate)}
                      peekNextMonth
                      showMonthDropdown
                      showYearDropdown
                      dropdownMode="select"
                      required
                    />
                  </Col>

                  <Col>
                    <Form.Select
                      name="position"
                      className="form-control"
                      aria-label="Job Title"
                      onChange={handleChange}
                      value={employee.position}
                      required
                    >
                      <option value="">Job Title</option>
                      <option value="UX/UI Developer">UX/UI Developer</option>
                      <option value="Node Developer">Node Developer</option>
                      <option value="MERN developer">MERN developer</option>
                      <option value="React developer">React developer</option>
                      <option value="PHP developer">PHP developer</option>
                      <option value="Wordpress developer">
                        Wordpress developer
                      </option>
                      <option value="Data analyst">Data analyst</option>
                      <option value="Data engineer">Data engineer</option>
                    </Form.Select>
                  </Col>
                  <Col>
                    <Form.Select
                      name="status"
                      className="form-control"
                      aria-label="status"
                      onChange={handleChange}
                      value={employee.status}
                      required
                    >
                      <option value="">Status</option>
                      <option value="Notice Period">Notice Period</option>
                      <option value="Left the Company">Left the Company</option>
                    </Form.Select>
                  </Col>
                </Row>
                <div className="addnewemployeebuttons mt-5">
                  <Button onClick={handlecancel} className="cancelbutton">
                    Cancel
                  </Button>

                  <Button type="submit" className="savebutton">
                    Save
                  </Button>
                </div>
                <div className="mt-2" style={{ width: 300 }}>
                  {error ? <Alert variant="danger">{errorMsg}</Alert> : null}
                </div>
              </div>
            </Form>
          </Modal.Body>
        </Modal>
      </div>
    </div>
  );
};

export default OldEmployee;
