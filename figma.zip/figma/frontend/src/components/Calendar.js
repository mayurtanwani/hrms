import React from "react";
import TwoDimensionalArrayDisplay from "./TwoDimensionalArrayDisplay";
const Calendar = ({
  startMonth,
  endMonth,
  employeeAttendance,
  year,
  holidays,
  setTotalDays,
  setTotalLeaves,
  setTotalHolidays,
  selectedPeriod,
  setEarlyLeaves,
  employee,
  setHalfDays,
}) => {
  const generateDateArray = (startMonth, endMonth, year) => {
    const startDate = new Date();
    startDate.setFullYear(year, startMonth, 21); // Set the start date to 20th of the start month
    startDate.setHours(0, 0, 0, 0); // Set the time to midnight

    const endDate = new Date();
    endDate.setFullYear(year, endMonth, 20); // Set the end date to 19th of the end month + 1
    endDate.setHours(23, 59, 59, 999); // Set the time to the end of the day

    const calendarDates = [];
    let currentDate = new Date(startDate);
    console.log("currentdate", currentDate);
    console.log("enddate", endDate);

    if (currentDate > endDate) {
      endDate.setFullYear(endDate.getFullYear() + 1);
    }

    console.log("currentdate", currentDate);
    console.log("enddate", endDate);

    while (currentDate <= endDate) {
      calendarDates.push(new Date(currentDate));
      currentDate.setDate(currentDate.getDate() + 1);
    }

    // Create an array of arrays
    const calendarArray = [];
    let tempArray = [];

    for (let i = 0; i < calendarDates.length; i++) {
      tempArray.push(calendarDates[i]);

      // Check if the date is the last day of the week or the last date
      if (
        calendarDates[i].getDay() === 6 || // Saturday (0-based index)
        i === calendarDates.length - 1 // Last date
      ) {
        calendarArray.push(tempArray);
        tempArray = [];
      }
    }

    return calendarArray;
  };

  const result = generateDateArray(startMonth, endMonth, year);
  console.log(result);

  while (result[0].length < 7) {
    result[0].unshift("");
  }

  while (result[result.length - 1].length < 7) {
    result[result.length - 1].push("");
  }

  result.unshift(["sun", "mon", "tue", "wed", "thu", "fri", "sat"]);

  console.log(result);
  return (
    <div>
      <TwoDimensionalArrayDisplay
        array={result}
        employeeAttendance={employeeAttendance}
        holidays={holidays}
        setTotalDays={setTotalDays}
        setTotalHolidays={setTotalHolidays}
        setTotalLeaves={setTotalLeaves}
        selectedPeriod={selectedPeriod}
        setEarlyLeaves={setEarlyLeaves}
        employee={employee}
        setHalfDays={setHalfDays}
      />
    </div>
  );
};

export default Calendar;
