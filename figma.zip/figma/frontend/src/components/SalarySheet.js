import React from "react";

const SalarySheet = () => {
  return (
    <div className="salary">
      <h4>Salary Sheet</h4>
      <p>
        The amount of salary paid to the employee before any deductions or
        additions. The number of days of leave taken by the employee during the
        payment method.{" "}
      </p>
    </div>
  );
};

export default SalarySheet;
