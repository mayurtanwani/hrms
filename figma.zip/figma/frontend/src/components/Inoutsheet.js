import React, { useEffect, useState } from "react";
import { fetchProducts } from "../redux/actions/actions";
import Leftsidebar from "./Leftsidebar";
import Loggedintopbar from "./Loggedintopbar";
import Button from "react-bootstrap/Button";
import { Link } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import Moment from "react-moment";
import mail from "../assets/mailbox.png";
import call from "../assets/call.png";
import ReactPaginate from "react-paginate";
import Modal from "react-bootstrap/Modal";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Row from "react-bootstrap/Row";
import EmployeeForm from "./SingleEmployeeForm";
import DatePicker from "react-datepicker";
import axios from "axios";
import { backend_uri_local } from "../utils/constant";
import { message } from "antd";

const Inoutsheet = () => {
  const [attendanceDate, setAttendanceDate] = useState(new Date());

  const [currentPage, setCurrentPage] = useState(0);
  const [show, setShow] = useState(false);

  const itemsPerPage = 6;
  const startIndex = currentPage * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const { data } = useSelector((state) => state.data);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchProducts());
  }, []);

  const slicedData =
    data &&
    data
      .filter((i) => i.status != "Left the Company")
      .slice(startIndex, endIndex);

  const addnew = () => {
    handleShow();
  };

  function handleShow(breakpoint) {
    setShow(true);
  }

  const handlecancel = () => {
    setShow(false);
  };
  const handleOk = () => {
    // Add or update the data here
    message.success("Data added/updated successfully!", 4);
  };

  const handleError = (data) => {
    // Add or update the data here

    message.error(data, 4);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);

    console.log("helllllllllllo", Object.fromEntries(formData));
    const alldata = [];

    data &&
      data.map((data) => {
        const newPersonData = {
          eid: formData.get(`eid${data.eid}`),
          name: formData.get(`name${data.eid}`),
          endtime: formData.get(`endtime${data.eid}`),
          starttime: formData.get(`startTime${data.eid}`),
          status: formData.get(`status${data.eid}`),
          date: attendanceDate,
        };
        alldata.push(newPersonData);
      });
    console.log(alldata);
    axios
      .post(`${backend_uri_local}/attendance`, alldata)
      .then((res) => {
        console.log(res);
        handleOk();
        setShow(false);
      })
      .catch((error) => {
        console.log(error.response.data.message);
        setShow(false);
        handleError(error.response.data.message);
      });

    // const newPersonData = {
    //   name: formData.get("name"),
    //   endtime: formData.get("endtime"),
    //   starttime: formData.get("startTime"),
    //   status: formData.get("status"),
    //   // add more properties as needed
    // };

    // console.log(alldata);

    // for (const pair of formData.entries()) {
    //   console.log(pair);
    // }

    // setPeopleData([...peopleData, newPersonData]);

    // console.log(peopleData);
  };
  return (
    <div className="inoutsheetmain">
      <div className="inoutsheetleft">
        <Leftsidebar />
      </div>
      {data && (
        <div className="inoutsheetright">
          <Loggedintopbar text="In-Out Sheet" />
          <div className="inoutsheetsecondbar">
            <h5>{data.length} Employees</h5>
            <Link>
              <Button onClick={addnew} className="linkAN">
                + Add Attendance
              </Button>
            </Link>
          </div>

          <div className="inoutsheetcontent">
            {data &&
              slicedData.map((data, i) => {
                return (
                  <Link to="/inoutsheetdetails" state={{ eid: data.eid }}>
                    <div className="singledivios" key={data.eid}>
                      <img src={data.image} />
                      <br />
                      <span className="nameins">
                        {data.firstname} {data.lastname}
                      </span>
                      <br />
                      <span className="positionins">{data.position}</span>
                      <br />
                      <span className="departmentins">Department</span>{" "}
                      <span className="joiningins">Date joining</span>
                      <br />
                      <span className="depertmentinsanswer">
                        {data.department}
                      </span>{" "}
                      <span className="dateins">
                        <Moment format="D MMM YYYY">{data.doj}</Moment>
                      </span>
                      <br />
                      <span className="emailins">
                        <img src={mail} /> {data.email}
                      </span>
                      <br />
                      <span className="contactins">
                        <img src={call} /> {data.contact}
                      </span>
                    </div>
                  </Link>
                );
              })}
          </div>

          <ReactPaginate
            pageCount={Math.ceil(data && data.length / itemsPerPage)}
            onPageChange={({ selected }) => setCurrentPage(selected)}
            containerClassName={"pagination"}
            pageClassName={"page-item"}
            pageLinkClassName={"page-link"}
            previousClassName={"page-item"}
            previousLinkClassName={"page-link"}
            nextClassName={"page-item"}
            nextLinkClassName={"page-link"}
            disabledClassName={"disabled"}
            activeClassName={"active"}
            previousLabel={"<"}
            nextLabel={">"}
          />
        </div>
      )}

      <Modal className="modal-lg" show={show} onHide={() => setShow(false)}>
        <Modal.Header closeButton>
          <Modal.Title id="example-custom-modal-styling-title">
            Add Attendance
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="mt-5">
            <Form
              onSubmit={handleSubmit}
              encType="multipart/form-data"
              id="myForm"
            >
              <Row>
                <Col></Col>
                <Col></Col>
                <Col></Col>

                <Col sx={2} className="mb-3 datepicker">
                  <DatePicker
                    className="form-control"
                    // placeholderText="Date"
                    showIcon
                    selected={attendanceDate}
                    onChange={(attendanceDate) =>
                      setAttendanceDate(attendanceDate)
                    }
                    todayButton="true"
                    peekNextMonth
                    showMonthDropdown
                    showYearDropdown
                    dropdownMode="select"
                    required
                  />
                </Col>
              </Row>

              <table>
                <thead>
                  <tr>
                    <th>Eid</th>
                    <th>Name</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                    <th>Status</th>
                  </tr>
                </thead>
              </table>
              <div>
                {data &&
                  data
                    .sort((a, b) => a.eid - b.eid)
                    .filter((i) => i.status != "Left the Company")
                    .map((employee) => (
                      <EmployeeForm key={employee.eid} employee={employee} />
                    ))}
              </div>
              <div className="addnewemployeebuttons mt-5">
                <Button onClick={handlecancel} className="cancelbutton">
                  Cancel
                </Button>

                <Button type="submit" className="savebutton">
                  Save
                </Button>
              </div>
            </Form>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default Inoutsheet;
