import React from 'react'
import search from "../assets/search.png"
import photo from "../assets/Profileimg.png"
const Dashboardtopbar = (props) => {
  return (
    <div className='loggedinbar'>
      <span className='dashboardtext'>{props.text}</span>
      <span className='images'>
        <img className="profilepic" src={photo}/>
        <img className="searchicon" src={search}/>
      </span>

    </div>
  )
}

export default Dashboardtopbar
