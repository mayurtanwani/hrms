import React from "react";
import search from "../assets/search.png";
import photo from "../assets/Profileimg.png";

const Loggedintopbar = (props) => {
  return (
    <div>
      <div className="loggedinbar">
        <span className="dashboardtext">{props.text}</span>
        <span className="images">
          <img className="searchicon" src={search} />
          <img className="profilepic" src={photo} />
        </span>
      </div>
    </div>
  );
};

export default Loggedintopbar;
