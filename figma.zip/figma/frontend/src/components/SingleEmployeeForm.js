import React, { useState } from "react";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Row from "react-bootstrap/Row";

function EmployeeForm({ employee }) {
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [status, setStatus] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle form submission here
  };

  return (
    <div className="attendanceform">
      <Row>
        <Col xs={1} className="eidcolumn">
          <Form.Control
            name={`eid${employee.eid}`}
            defaultValue={employee.eid}
            readOnly
          />
        </Col>
        <Col>
          <Form.Control
            name={`name${employee.eid}`}
            placeholder={`${employee.firstname} ${employee.lastname}`}
            defaultValue={`${employee.firstname} ${employee.lastname}`}
            readOnly
          />
        </Col>

        <Col>
          <Form.Control
            name={`startTime${employee.eid}`}
            type="time"
            value={startTime}
            placeholder="Start Time"
            onChange={(event) => setStartTime(event.target.value)}
          />
        </Col>

        <Col>
          <Form.Control
            name={`endtime${employee.eid}`}
            type="time"
            value={endTime}
            placeholder="End Time"
            onChange={(event) => setEndTime(event.target.value)}
          />
        </Col>

        <Col>
          <Form.Select
            name={`status${employee.eid}`}
            value={status}
            onChange={(event) => setStatus(event.target.value)}
            required
          >
            <option value="">Status</option>
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
          </Form.Select>
        </Col>
      </Row>
    </div>
  );
}

export default EmployeeForm;
