import React from 'react'
import homeimage1 from '../assets/Homepage_img.png'
const HomeImage = () => {
  return (
    <div className="homeimg"> 
      <img src={homeimage1}/>
    </div>
  )
}

export default HomeImage
