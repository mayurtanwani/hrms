import React from 'react'
import logo from '../assets/ntf.png'
import { useNavigate, Link } from 'react-router-dom'

const Topbar = (props) => {
  return (
    
    <div className='topbar'>
        <Link to="/" ><img className="logo" src={logo} /></Link>
        <Link className="link" to={props.link}><button className='loginbutton'>{props.text}</button></Link>
    </div>
    
    
    
  )
}

export default Topbar
