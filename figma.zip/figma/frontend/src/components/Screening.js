import React from 'react'

const Screening = () => {
  return (
    <div className='screening'>
      <h4>Candidate Screening</h4>
      <p>Reviewing Resumes And Cover Letters To Identitfy Qualified Candidates And Conducting Initial Phone Screens To Assess Thier Suitability For The Position.</p>
    </div>
  )
}

export default Screening
