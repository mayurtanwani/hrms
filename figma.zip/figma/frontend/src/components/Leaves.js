import React from "react";
import Calendar from "./Calendar";
import Leftsidebar from "./Leftsidebar";
import Loggedintopbar from "./Loggedintopbar";
import Form from "react-bootstrap/Form";
import { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchProducts } from "../redux/actions/actions";
import { getAttendance } from "../redux/actions/actions";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import axios from "axios";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";

const Leaves = () => {
  const { data } = useSelector((state) => state.data);
  const [holidays, setHolidays] = useState([]);

  const [selectedPeriod, setSelectedPeriod] = useState("3 4");
  const [employee, setEmployee] = useState("");
  const { attendanceData } = useSelector((state) => state.attendanceData);
  const dispatch = useDispatch();
  const [startDate, setStartDate] = useState(new Date());
  const [totalDays, setTotalDays] = useState(0);
  const [totalHolidays, setTotalHolidays] = useState(0);
  const [totalLeaves, setTotalLeaves] = useState(0);
  const [earlyLeaves, setEarlyLeaves] = useState(0);
  const [halfDays, setHalfDays] = useState(0);

  const todaydate = new Date();

  const year = startDate.getFullYear();

  useEffect(() => {
    dispatch(getAttendance());
  }, []);

  useEffect(() => {
    const fetchHolidays = async () => {
      try {
        const response = await axios.get(
          "https://calendarific.com/api/v2/holidays",
          {
            params: {
              api_key: "63ab648a65125168b166cdaf3d613992102c9a15",
              country: "IN",
              year: year,
            },
          }
        );
        setHolidays(response.data.response.holidays);
      } catch (error) {
        console.log(error);
      }
    };

    fetchHolidays();
  }, []);

  const handlePeriodChange = (event) => {
    setSelectedPeriod(event.target.value);
  };

  const handleEmployeeChange = (event) => {
    setEmployee(event.target.value);
  };

  useEffect(() => {
    dispatch(fetchProducts());
  }, []);

  const employeeAttendance =
    attendanceData &&
    attendanceData.allAttendance.filter((item) => item.eid == employee);

  console.log(data);
  console.log(employee);

  const selectedEmployee =
    data && employee && data.filter((i) => i.eid === employee);

  console.log(selectedEmployee);
  const employeeName =
    employee &&
    selectedEmployee[0].firstname + " " + selectedEmployee[0].lastname;
  const startMonth = selectedPeriod && selectedPeriod.split(" ")[0];
  const endMonth = selectedPeriod && selectedPeriod.split(" ")[1];

  console.log("employeename", employeeName);
  console.log(data);
  const newdata =
    data &&
    data
      .filter((i) => i.status != "Left the Company")
      .sort((a, b) => a.eid - b.eid);

  if (todaydate.getDate > 20) {
    var selectdefaultValue = `${todaydate.getMonth()} ${
      todaydate.getMonth() + 1
    }`;
  } else {
    var selectdefaultValue = `${
      todaydate.getMonth() - 1
    } ${todaydate.getMonth()}`;
  }
  return (
    <div>
      <div className="leavesLeft">
        <Leftsidebar />
      </div>
      <div style={{ marginLeft: "270px" }}>
        <Loggedintopbar text="Leaves" />
        <div className="d-flex">
          <div>
            <div className="d-flex justify-content-evenly mb-5">
              <div className="d-flex flex-column align-items-center justify-content-center">
                <div style={{ width: "150px" }}>
                  <CircularProgressbar
                    strokeWidth={9}
                    styles={buildStyles({
                      pathColor: "#64DAFF",
                      textColor: "#64DAFF",
                      trailColor: "#B8EEFF",
                      textSize: "30px",
                      textWeight: "800",
                    })}
                    value={(totalLeaves * 100) / totalDays}
                    text={totalLeaves == 0 ? "0" : totalLeaves}
                  />
                </div>
                <div
                  style={{
                    fontSize: "20px",
                    fontWeight: "600",
                    marginTop: "10px",
                  }}
                >
                  Total Leave
                </div>
              </div>
              <div className="d-flex flex-column align-items-center justify-content-center">
                <div style={{ width: "150px" }}>
                  <CircularProgressbar
                    strokeWidth={9}
                    styles={buildStyles({
                      pathColor: "#A3CE8F",
                      textColor: "#A3CE8F",
                      trailColor: "#E7FFDB",
                      textSize: "30px",
                      textWeight: "800",
                    })}
                    value={(earlyLeaves * 100) / totalDays}
                    text={earlyLeaves == 0 ? "0" : earlyLeaves}
                  />
                </div>
                <div
                  style={{
                    fontSize: "20px",
                    fontWeight: "600",
                    marginTop: "10px",
                  }}
                >
                  Total Early Leaves
                </div>
              </div>
              <div className="d-flex flex-column align-items-center justify-content-center">
                <div style={{ width: "150px" }}>
                  <CircularProgressbar
                    strokeWidth={9}
                    styles={buildStyles({
                      pathColor: "#FEA633",
                      textColor: "#FEA633",
                      trailColor: "#ffe8ca",
                      textSize: "30px",
                      textWeight: "800",
                    })}
                    value={(halfDays * 100) / totalDays}
                    text={halfDays == 0 ? "0" : halfDays}
                  />
                </div>
                <div
                  style={{
                    fontSize: "20px",
                    fontWeight: "600",
                    marginTop: "10px",
                  }}
                >
                  Total Half Days
                </div>
              </div>
            </div>
            <div
              className="selectors d-flex justify-content-end align-items-center mb-4 gap-2"
              style={{ width: "750px" }}
            >
              <div
                style={{
                  color: "#666666",
                  fontFamily: "Poppins",
                  fontSize: "16px",
                  fontWeight: "800",
                }}
                className="me-3"
              >
                {employeeName && employeeName}
              </div>
              <div style={{ width: "180px" }}>
                <Form.Select
                  onChange={handleEmployeeChange}
                  className="form-control"
                  aria-label="Language"
                  required
                >
                  <option value="">Select Employee ID</option>
                  {newdata &&
                    newdata.map((item, i) => {
                      return (
                        <option key={i} value={item.eid}>
                          {item.eid < 10
                            ? `eid 0${item.eid}`
                            : `eid ${item.eid}`}
                        </option>
                      );
                    })}
                </Form.Select>
              </div>
              <div style={{ width: "150px" }}>
                <Form.Select
                  name="language"
                  onChange={handlePeriodChange}
                  className="form-control"
                  aria-label="Language"
                  required
                  defaultValue={selectdefaultValue}
                >
                  <option value="">Select Period</option>
                  <option value="0 1">Jan-Feb</option>
                  <option value="1 2">Feb-Mar</option>
                  <option value="2 3">Mar-Apr</option>
                  <option value="3 4">Apr-May</option>
                  <option value="4 5">May-Jun</option>
                  <option value="5 6">Jun-Jul</option>
                  <option value="6 7">Jul-Aug</option>
                  <option value="7 8">Aug-Sep</option>
                  <option value="8 9">Sep-Oct</option>
                  <option value="9 10">Oct-Nov</option>
                  <option value="10 11">Nov-Dec</option>
                  <option value="11 0">Dec-Jan</option>
                </Form.Select>
              </div>
              <div
                style={{
                  width: "50px",
                  paddingLeft: "0px",
                  marginRight: "10px",
                }}
                className="d-flex align-items-center justify-content-center"
              >
                <DatePicker
                  selected={startDate}
                  onChange={(date) => setStartDate(date)}
                  showYearPicker
                  dateFormat="yyyy"
                />
              </div>
            </div>
            <div className="leavestable">
              <Calendar
                startMonth={startMonth}
                endMonth={endMonth}
                employeeAttendance={employeeAttendance}
                year={year}
                holidays={holidays}
                setTotalDays={setTotalDays}
                setTotalLeaves={setTotalLeaves}
                setTotalHolidays={setTotalHolidays}
                selectedPeriod={selectedPeriod}
                setEarlyLeaves={setEarlyLeaves}
                employee={employee}
                setHalfDays={setHalfDays}
              />
            </div>
          </div>
          <div className="d-flex flex-column ">
            <div
              className="ps-5"
              style={{ fontSize: "16px", fontWeight: "700" }}
            >
              Upcoming Public Holidays
            </div>
            <div
              style={{ height: "75vh", overflowX: "auto", fontSize: "12px" }}
              className=" py-4 px-3"
            >
              {holidays &&
                holidays.map((item, i) => {
                  const date1 = new Date(item.date.iso);
                  const weekdays = [
                    "Sunday",
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                  ];
                  return (
                    <div
                      style={{
                        fontFamily: "Poppins",
                        fontWeight: "600",
                        fontSize: "12px",
                        lineHeight: "18px",
                        color: "#666666",
                      }}
                      className="d-flex justify-content-between  p-3"
                    >
                      <div className="d-flex flex-column">
                        <div>{item.date.iso}</div>
                        <div>{weekdays[date1.getDay()]}</div>
                      </div>
                      <div style={{ textAlign: "right" }}>{item.name}</div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Leaves;
