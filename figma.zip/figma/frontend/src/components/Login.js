import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from "axios";
import logo from "../assets/ntf.png";
import image from "../assets/Abstract.png";
import Alert from "react-bootstrap/Alert";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import { backend_uri_local } from "../utils/constant";

function Login() {
  const [error, setError] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const reggisterbuttontext = "Register";
  const navigate = useNavigate();
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const submitHandler = async (e) => {
    e.preventDefault();

    await axios
      .post(`${backend_uri_local}/login`, formData)
      .then((response) => {
        if (response) {
          localStorage.setItem("token", response.data.token);
          navigate("/dashboard");
        }
      })
      .catch((err) => {
        console.log(err.response);
        setError(true);
        setErrorMsg(err.response.data.msg);
      });
  };

  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  return (
    <>
      <div className="loginmain">
        <div className="imagediv">
          <img src={image} />
        </div>

        <div className="loginformmain">
          <Link className="loginlogo" to="/">
            <img src={logo} />
          </Link>

          <div className="loginform">
            <div className="heading">
              <h2>Login</h2>
            </div>
            <Form onSubmit={submitHandler}>
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Email address</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Enter Email Address"
                  onChange={handleChange}
                  name="email"
                  value={formData.email}
                />
              </Form.Group>

              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control
                  type="password"
                  placeholder="Enter Password"
                  onChange={handleChange}
                  name="password"
                  value={formData.password}
                />
              </Form.Group>
              <Link className="forgotpassword" to="">
                Forgot Password?
              </Link>

              <div className="buttons">
                <Button
                  className="loginbutton2"
                  variant="primary"
                  type="submit"
                >
                  Login
                </Button>

                <div className="signup">
                  Don't have an account?
                  <Link className="link4" to="/register">
                    create an account
                  </Link>
                </div>
              </div>
            </Form>
            <div className="errordiv">
              {error && <Alert variant="danger">{errorMsg}</Alert>}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Login;
