import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from "axios";
import logo from "../assets/ntf.png";
import image from "../assets/Abstract.png";
import Alert from "react-bootstrap/Alert";
import { backend_uri_local } from "../utils/constant";

function Register() {
  const [error, setError] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const navigate = useNavigate();
  const loginbuttontext = "Login";

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const submitHandler = async (e) => {
    e.preventDefault();
    console.log(formData);
    await axios
      .post(`${backend_uri_local}/register`, formData)
      .then((response) => {
        if (response) {
          console.log(response);
          navigate("/login");
        }
      })
      .catch((err) => {
        console.log(err.response);
        setError(true);
        setErrorMsg(err.response.data.msg);
      });
  };

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmpassword: "",
  });

  return (
    <>
      <div className="registermain">
        <div className="imagediv2">
          <img src={image} />
        </div>
        <div className="form2">
          <div className="registerlogo">
            <Link to="/">
              <img src={logo} />
            </Link>
          </div>

          <div className="registerform">
            <div className="heading">
              <h2>Sign up </h2>
            </div>
            <Form onSubmit={submitHandler}>
              <Form.Group className="mb-3" controlId="formBasicName">
                <Form.Label>Full Name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Your Full Name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                />
              </Form.Group>
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Email address</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Enter Email Address"
                  name="email"
                  value={formData.value}
                  onChange={handleChange}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Password</Form.Label>
                <Form.Control
                  type="password"
                  placeholder="Enter Password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Confirm Password</Form.Label>
                <Form.Control
                  type="password"
                  placeholder="Enter Password Again"
                  name="confirmpassword"
                  value={formData.confirmpassword}
                  onChange={handleChange}
                />
              </Form.Group>

              <div className="buttons">
                <Button
                  className="registerbutton"
                  variant="primary"
                  type="submit"
                >
                  Register
                </Button>
              </div>
            </Form>
            <div className="errordiv">
              {error && <Alert variant="danger">{errorMsg}</Alert>}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Register;
