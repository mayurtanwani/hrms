let initialState = {
  loading: false,
  data: [],
  error: null,
  candidateData: [],
};

export const employeeReducer = (state = initialState, action) => {
  switch (action.type) {
    case "FETCH_DATA_REQUEST":
      return {
        ...state,
        loading: true,
      };
    case "FETCH_DATA_SUCCESS":
      return {
        loading: false,
        data: action.payload,
        error: "",
      };
    case "FETCH_DATA_FAILURE":
      return {
        loading: false,
        error: action.payload,
      };

    default:
      return state;
  }
};

export const candidateReducer = (state = initialState, action) => {
  switch (action.type) {
    case "FETCH_CANDIDATE_REQUEST":
      return {
        ...state,
        loading: true,
      };
    case "FETCH_CANDIDATE_SUCCESS":
      return {
        loading: false,
        candidateData: action.payload,
        error: "",
      };
    case "FETCH_CANDIDATE_FAILURE":
      return {
        loading: false,
        error: action.payload,
      };
    default:
      return state;
  }
};

export const getAttendanceReducer = (state = initialState, action) => {
  switch (action.type) {
    case "GET_ATTENDANCE_REQUEST":
      return {
        ...state,
        loading: true,
      };
    case "GET_ATTENDANCE_SUCCESS":
      return {
        loading: false,
        attendanceData: action.payload,
        error: "",
      };
    case "GET_ATTENDANCE_FAILURE":
      return {
        loading: false,
        error: action.payload,
      };
    default:
      return state;
  }
};
