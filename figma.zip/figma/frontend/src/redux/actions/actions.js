import {
  FETCH_DATA_FAILURE,
  FETCH_DATA_REQUEST,
  FETCH_DATA_SUCCESS,
  FETCH_CANDIDATE_REQUEST,
  FETCH_CANDIDATE_SUCCESS,
  FETCH_CANDIDATE_FAILURE,
  DELETE_CANDIDATE_REQUEST,
  DELETE_CANDIDATE_FAILURE,
  GET_ATTENDANCE_FAILURE,
  GET_ATTENDANCE_REQUEST,
  GET_ATTENDANCE_SUCCESS,
} from "../constants/constants";
import axios from "axios";
import { backend_uri_local } from "../../utils/constant";

export const fetchProducts = () => (dispatch) => {
  try {
    dispatch({ type: FETCH_DATA_REQUEST });
    axios
      .get(`${backend_uri_local}/employees`)
      .then((response) => {
        console.log("response", response);
        dispatch({
          type: FETCH_DATA_SUCCESS,
          payload: response.data.employees,
        });
      })
      .catch((error) => {
        dispatch({
          type: FETCH_DATA_FAILURE,
          payload:
            error.response && error.response.data.message
              ? error.response.data.message
              : error.message,
        });
      });
  } catch (error) {
    dispatch({
      type: FETCH_DATA_FAILURE,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    });
  }
};

export const getCandidates = () => (dispatch) => {
  try {
    dispatch({ type: FETCH_CANDIDATE_REQUEST });
    axios
      .get(`${backend_uri_local}/candidates`)
      .then((response) => {
        console.log("response", response);
        dispatch({
          type: FETCH_CANDIDATE_SUCCESS,
          payload: response.data.candidates,
        });
      })
      .catch((error) => {
        console.log("error", error);
      });
  } catch (error) {
    dispatch({
      type: FETCH_CANDIDATE_FAILURE,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    });
  }
};

export const deleteCandidate = (id) => (dispatch) => {
  try {
    dispatch({ type: DELETE_CANDIDATE_REQUEST });
    axios
      .delete(`${backend_uri_local}/candidate/${id}`)
      .then((response) => {
        console.log("response", response);
        dispatch({
          type: FETCH_CANDIDATE_SUCCESS,
          payload: response.data.candidates,
        });
      })
      .catch((error) => {
        console.log("error", error);
      });
  } catch (error) {
    dispatch({
      type: DELETE_CANDIDATE_FAILURE,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    });
  }
};

export const getAttendance = () => (dispatch) => {
  try {
    dispatch({ type: GET_ATTENDANCE_REQUEST });
    axios
      .get(`${backend_uri_local}/getallattendance`)
      .then((response) => {
        console.log("response", response);
        dispatch({
          type: GET_ATTENDANCE_SUCCESS,
          payload: response.data,
        });
      })
      .catch((error) => {
        console.log("error", error);
      });
  } catch (error) {
    dispatch({
      type: GET_ATTENDANCE_FAILURE,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    });
  }
};
